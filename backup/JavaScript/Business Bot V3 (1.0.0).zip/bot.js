(async()=>{
                let process = require('process');
                process.on('uncaughtException', function (err) {
                    console.log(`Error!`);
                    console.log(err);
                  });
                                  const ShsHSjJSjSJSJSGHkkhdjdmns = ['CREATE_INSTANT_INVITE','MANAGE_CHANNELS','ADD_REACTIONS','STREAM','VIEW_CHANNEL','SEND_MESSAGES','SEND_TTS_MESSAGES','MANAGE_MESSAGES','EMBED_LINKS','ATTACH_FILES','READ_MESSAGE_HISTORY','MENTION_EVERYONE','USE_EXTERNAL_EMOJIS','CONNECT','SPEAK','USE_VAD','CHANGE_NICKNAME','MANAGE_ROLES','MANAGE_WEBHOOKS','USE_APPLICATION_COMMANDS','REQUEST_TO_SPEAK','MANAGE_THREADS','USE_PUBLIC_THREADS','CREATE_PUBLIC_THREADS','USE_PRIVATE_THREADS','CREATE_PRIVATE_THREADS','USE_EXTERNAL_STICKERS','SEND_MESSAGES_IN_THREADS','START_EMBEDDED_ACTIVITIES'
                         
                         
     
     
     
             
             
     
     
     
                         
                         ]
                  const events = require('events');
                  const { exec } = require("child_process")
                  const S4D_APP_RUN_BUTTON = false
                  let Discord = require("discord.js")
let Database  = require("easy-json-database")
let { MessageEmbed, MessageButton, MessageActionRow, Intents, Permissions, MessageSelectMenu }= require("discord.js")
let logs = require("discord-logs")
const os = require("os-utils");
let URL = require('url')
const ms = require("ms")
const Captcha = require("@haileybot/captcha-generator");
let fs = require('fs');
                    const devMode = typeof __E_IS_DEV !== "undefined" && __E_IS_DEV;
                    const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
                    const s4d = {
                        Discord,
                        database: new Database(`./database.json`),
fire:null,
                        joiningMember:null,
                        reply:null,
                        tokenInvalid:false,
                        tokenError: null,
                        player:null,
                        manager:null,
                        Inviter:null,
                        message:null,
                        notifer:null,
                        checkMessageExists() {
                            if (!s4d.client) throw new Error('You cannot perform message operations without a Discord.js client')
                            if (!s4d.client.readyTimestamp) throw new Error('You cannot perform message operations while the bot is not connected to the Discord API')
                        }
                    };
                    s4d.client = new s4d.Discord.Client({
                    intents: [Object.values(s4d.Discord.Intents.FLAGS).reduce((acc, p) => acc | p, 0)],
                    partials: ["REACTION", "CHANNEL"]
                    });
                    s4d.client.on('ready', () => {
                        console.log(s4d.client.user.tag + " is alive!")
                    })
                    logs(s4d.client);         
                    var xp_args, xp, level_args, level;


await s4d.client.login('ODc1NjUyMDk1NDgxNjIyNTk4.GlWdJP.6La_-qS9bHbYJXpKNhIFOH8B4eWXCogJtYJ1wI').catch((e) => {
        s4d.tokenInvalid = true;
        s4d.tokenError = e;
        if (e.toString().toLowerCase().includes("token")) {
            throw new Error("An invalid token was provided!")
        } else {
            throw new Error("Intents are not turned on!")
        }
    });

// Commandes d'aide
s4d.client.on('messageCreate', async (s4dmessage) => {
  if ((s4dmessage.content) == String(s4d.database.get(String('prefix'))) + 'help') {
    (s4dmessage.channel).send({
                embeds: [new MessageEmbed()
    .setTitle(String((String(s4d.database.get(String('bot_emoji'))) + '** | Business Bot V3 - Menu d\'aide**')))
    .setColor(String(s4d.database.get(String('embed_color'))))
    .setDescription(String((['**<a:bot_house:986675888911446066> | Menu Principal**','\n','\n','- Bot `officiel` de **',(s4dmessage.guild).name,'**, je possède de nombreuses commandes que vous pouvez consulter en interagissant avec le menu.','\n','\n','- Mon développeur est **',(((s4dmessage.guild).members.cache.get('397406757422628869') || await (s4dmessage.guild).members.fetch('397406757422628869')).user).tag,' ( <@397406757422628869> )**, si tu veux avoir une version similaire de moi-même, contact le par MP.','\n','\n','<a:bot_loupe:986674310913617920> **| Légende:**','\n','\n','- *<a:bot_good:986673556777734206> | commande `Disponible`*','\n','- *<a:bot_notgood:986673549773266954> | commande `Indisponible`*','','',''].join(''))))
    .setFooter(String(('Demandé par ' + String((s4dmessage.author).tag))))
                ]
        ,components:[(new MessageActionRow()
        .addComponents(
        new MessageSelectMenu()
        .setCustomId('help-menu')
        .setPlaceholder('Interagir pour consulter les comandes')
        .setMaxValues(1)
        .setMinValues(1)
        .setDisabled(false)


        .addOptions(  {
      value:'menu_house',
      label:'Menu Principal',
      emoji:'<a:bot_house:986675888911446066>',
      description:'Retourner au menu principal',
      default:false,},
      {
      value:'menu_utils',
      label:'Utilitaire',
      emoji:'<:bot_tools:986669486461575270>',
      description:'Commandes utilitaires',
      default:false,},
      {
      value:'menu_music',
      label:'Juke-Box',
      emoji:'<:bot_radio:986669484695756830>',
      description:'Commandes de musique',
      default:false,},
      {
      value:'menu_moderator',
      label:'Modération',
      emoji:'<:bot_moderator:986669488466456636>',
      description:'Commandes de modération',
      default:false,},
      {
      value:'menu_admin',
      label:'Propriétaires',
      emoji:'<:bot_owner:986666412795920435>',
      description:'Commandes accessible seulement par les propriétaires',
      default:false,},
    ))
    )]}).then(m=>{
                      let collector = m.createMessageComponentCollector({filter: i=>i.user.id === (s4dmessage.member).id ,time:60000});
          collector.on('collect',async i=>{
                if ((i.customId) == 'help-menu' && (i.values[0]) == 'menu_admin') {
          await i.update({
                      embeds: [new MessageEmbed()
          .setTitle(String((String(s4d.database.get(String('bot_emoji'))) + '** | Business Bot V3 - Menu d\'aide**')))
          .setColor(String(s4d.database.get(String('embed_color'))))
          .setDescription(String((['> <a:bot_good:986673556777734206> `!demote` = *Retirer tous les rôles d\'un haut gradé.*','\n','> <a:bot_good:986673556777734206> `!ghostping` = *Configurer le système de ghostping.*','\n','> <a:bot_good:986673556777734206> `!manage-pub` = *Gérer le système d\'embed derrière les publicités.*','\n','> <a:bot_good:986673556777734206> `!color_embed` = *Modifier la couleur de tous les embeds du bot.*','\n','> <a:bot_good:986673556777734206> `!message_mp` = *Configurer le message à envoyer aux nouveaux.*','\n','> <a:bot_good:986673556777734206> `!partenariat_add` = *Ajouter les accès à la commande de partenariat à un nouveau équipier.*','\n','> <a:bot_good:986673556777734206> `!partenariat_remove` = *Retirer les accès à la commande de partenariat à un équipier.*','\n','> <a:bot_good:986673556777734206> `!shutdown` = *Eteindre le bot.*','\n','> <a:bot_good:986673556777734206> `!money_add` = *Ajouter des coins à un équipier.*','\n','> <a:bot_good:986673556777734206> `!money_remove` = *Enlever des coins à un équipier.*','\n','> <a:bot_good:986673556777734206> `!say` = *Faire parler le bot.*','\n','> <a:bot_good:986673556777734206> `!embed` = *Envoyer un embed de qualité !*'].join(''))))
          .setFooter(String(('Demandé par ' + String((s4dmessage.author).tag))))
                      ]
              ,components:[(new MessageActionRow()
              .addComponents(
              new MessageSelectMenu()
              .setCustomId('help-menu')
              .setPlaceholder('Interagir pour consulter les comandes')
              .setMaxValues(1)
              .setMinValues(1)
              .setDisabled(false)


              .addOptions(  {
            value:'menu_house',
            label:'Menu Principal',
            emoji:'<a:bot_house:986675888911446066>',
            description:'Retourner au menu principal',
            default:false,},
            {
            value:'menu_utils',
            label:'Utilitaire',
            emoji:'<:bot_tools:986669486461575270>',
            description:'Commandes utilitaires',
            default:false,},
            {
            value:'menu_music',
            label:'Juke-Box',
            emoji:'<:bot_radio:986669484695756830>',
            description:'Commandes de musique',
            default:false,},
            {
            value:'menu_moderator',
            label:'Modération',
            emoji:'<:bot_moderator:986669488466456636>',
            description:'Commandes de modération',
            default:false,},
            {
            value:'menu_admin',
            label:'Propriétaires',
            emoji:'<:bot_owner:986666412795920435>',
            description:'Commandes accessible seulement par les propriétaires',
            default:false,},
          ))
          )]}).then(m=>{

                      });
        }
        if ((i.customId) == 'help-menu' && (i.values[0]) == 'menu_utils') {
          await i.update({
                      embeds: [new MessageEmbed()
          .setTitle(String((String(s4d.database.get(String('bot_emoji'))) + '** | Business Bot V3 - Menu d\'aide**')))
          .setColor(String(s4d.database.get(String('embed_color'))))
          .setDescription(String((['> <a:bot_good:986673556777734206> `!member_count` = *Afficher le nombre de membres présents sur le serveur.*','\n','> <a:bot_good:986673556777734206> `!bot_count` = *Afficher le nombre de bots présents sur le serveur.*','\n','> <a:bot_good:986673556777734206> `!chanel_count` = *Afficher le nombre de salons sur le serveur.*','\n','> <a:bot_good:986673556777734206> `!pub_count` = *Afficher le nombre de publicités accueillies par Business Pub depuis la V1 du bot.*','\n','> <a:bot_good:986673556777734206> `!level` = *Afficher le niveau atteint par un utilisateur.*','\n','> <a:bot_good:986673556777734206> `!xp` = *Afficher le nombre d\'XP atteints par un utilisateur.*','\n','> <a:bot_good:986673556777734206> `!ping` = *Afficher le ping du bot.*','','','','','','','','',''].join(''))))
          .setFooter(String(('Demandé par ' + String((s4dmessage.author).tag))))
                      ]
              ,components:[(new MessageActionRow()
              .addComponents(
              new MessageSelectMenu()
              .setCustomId('help-menu')
              .setPlaceholder('Interagir pour consulter les comandes')
              .setMaxValues(1)
              .setMinValues(1)
              .setDisabled(false)


              .addOptions(  {
            value:'menu_house',
            label:'Menu Principal',
            emoji:'<a:bot_house:986675888911446066>',
            description:'Retourner au menu principal',
            default:false,},
            {
            value:'menu_utils',
            label:'Utilitaire',
            emoji:'<:bot_tools:986669486461575270>',
            description:'Commandes utilitaires',
            default:false,},
            {
            value:'menu_music',
            label:'Juke-Box',
            emoji:'<:bot_radio:986669484695756830>',
            description:'Commandes de musique',
            default:false,},
            {
            value:'menu_moderator',
            label:'Modération',
            emoji:'<:bot_moderator:986669488466456636>',
            description:'Commandes de modération',
            default:false,},
            {
            value:'menu_admin',
            label:'Propriétaires',
            emoji:'<:bot_owner:986666412795920435>',
            description:'Commandes accessible seulement par les propriétaires',
            default:false,},
          ))
          )]}).then(m=>{

                      });
        }
        if ((i.customId) == 'help-menu' && (i.values[0]) == 'menu_music') {
          await i.update({
                      embeds: [new MessageEmbed()
          .setTitle(String((String(s4d.database.get(String('bot_emoji'))) + '** | Business Bot V3 - Menu d\'aide**')))
          .setColor(String(s4d.database.get(String('embed_color'))))
          .setDescription(String((['> <a:bot_good:986673556777734206> `!play` = *Allumer la musique.*','\n','> <a:bot_good:986673556777734206> `!stop` = *Stopper la musique en cours.*','\n','> <a:bot_good:986673556777734206> `!pause` = *Mettre la musique en cours sur pause.*','\n','> <a:bot_good:986673556777734206> `!resume` = *Reprendre une musique mise sur pause.*','\n','> <a:bot_good:986673556777734206> `!volume` = *Gérer le volume.*','\n','> <a:bot_good:986673556777734206> `!skip` = *Passer à la musique suivante.*','\n','> <a:bot_good:986673556777734206> `!back` = *Réécouter la musique précédente.*','','','','','','','','',''].join(''))))
          .setFooter(String(('Demandé par ' + String((s4dmessage.author).tag))))
                      ]
              ,components:[(new MessageActionRow()
              .addComponents(
              new MessageSelectMenu()
              .setCustomId('help-menu')
              .setPlaceholder('Interagir pour consulter les comandes')
              .setMaxValues(1)
              .setMinValues(1)
              .setDisabled(false)


              .addOptions(  {
            value:'menu_house',
            label:'Menu Principal',
            emoji:'<a:bot_house:986675888911446066>',
            description:'Retourner au menu principal',
            default:false,},
            {
            value:'menu_utils',
            label:'Utilitaire',
            emoji:'<:bot_tools:986669486461575270>',
            description:'Commandes utilitaires',
            default:false,},
            {
            value:'menu_music',
            label:'Juke-Box',
            emoji:'<:bot_radio:986669484695756830>',
            description:'Commandes de musique',
            default:false,},
            {
            value:'menu_moderator',
            label:'Modération',
            emoji:'<:bot_moderator:986669488466456636>',
            description:'Commandes de modération',
            default:false,},
            {
            value:'menu_admin',
            label:'Propriétaires',
            emoji:'<:bot_owner:986666412795920435>',
            description:'Commandes accessible seulement par les propriétaires',
            default:false,},
          ))
          )]}).then(m=>{

                      });
        }
        if ((i.customId) == 'help-menu' && (i.values[0]) == 'menu_house') {
          await i.update({
                      embeds: [new MessageEmbed()
          .setTitle(String((String(s4d.database.get(String('bot_emoji'))) + '** | Business Bot V3 - Menu d\'aide**')))
          .setColor(String(s4d.database.get(String('embed_color'))))
          .setDescription(String((['**<a:bot_house:986675888911446066> | Menu Principal**','\n','\n','- Bot `officiel` de **',(s4dmessage.guild).name,'**, je possède de nombreuses commandes que vous pouvez consulter en interagissant avec le menu.','\n','\n','- Mon développeur est **',(((s4dmessage.guild).members.cache.get('397406757422628869') || await (s4dmessage.guild).members.fetch('397406757422628869')).user).tag,' ( <@397406757422628869> )**, si tu veux avoir une version similaire de moi-même, contact le par MP.','\n','\n','<a:bot_loupe:986674310913617920> **| Légende:**','\n','\n','- *<a:bot_good:986673556777734206> | commande `Disponible`*','\n','- *<a:bot_notgood:986673549773266954> | commande `Indisponible`*','','',''].join(''))))
          .setFooter(String(('Demandé par ' + String((s4dmessage.author).tag))))
                      ]
              ,components:[(new MessageActionRow()
              .addComponents(
              new MessageSelectMenu()
              .setCustomId('help-menu')
              .setPlaceholder('Interagir pour consulter les comandes')
              .setMaxValues(1)
              .setMinValues(1)
              .setDisabled(false)


              .addOptions(  {
            value:'menu_house',
            label:'Menu Principal',
            emoji:'<a:bot_house:986675888911446066>',
            description:'Retourner au menu principal',
            default:false,},
            {
            value:'menu_utils',
            label:'Utilitaire',
            emoji:'<:bot_tools:986669486461575270>',
            description:'Commandes utilitaires',
            default:false,},
            {
            value:'menu_music',
            label:'Juke-Box',
            emoji:'<:bot_radio:986669484695756830>',
            description:'Commandes de musique',
            default:false,},
            {
            value:'menu_moderator',
            label:'Modération',
            emoji:'<:bot_moderator:986669488466456636>',
            description:'Commandes de modération',
            default:false,},
            {
            value:'menu_admin',
            label:'Propriétaires',
            emoji:'<:bot_owner:986666412795920435>',
            description:'Commandes accessible seulement par les propriétaires',
            default:false,},
          ))
          )]}).then(m=>{

                      });
        }
        if ((i.customId) == 'help-menu' && (i.values[0]) == 'menu_moderator') {
          await i.update({
                      embeds: [new MessageEmbed()
          .setTitle(String((String(s4d.database.get(String('bot_emoji'))) + '** | Business Bot V3 - Menu d\'aide**')))
          .setColor(String(s4d.database.get(String('embed_color'))))
          .setDescription(String((['> <a:bot_good:986673556777734206> `!ban` = *Bannir un utilisateur du serveur.*','\n','> <a:bot_good:986673556777734206> `!unban` = *Debannir un utilisateur du serveur.*','\n','> <a:bot_good:986673556777734206> `!kick` = *Expulser un utilisateur du serveur.*','\n','> <a:bot_good:986673556777734206> `!clear` = *Effacer un certain nombre de message.*','\n','> <a:bot_good:986673556777734206> `!clear` = *Effacer un certain nombre de message.*','\n','> <a:bot_good:986673556777734206> `!partenariat` = *Configurer un partenariat.*','\n','> <a:bot_good:986673556777734206> `!partenariat_count/!part_count` = *Afficher le nombre de partenariats faits.*','\n','> <a:bot_good:986673556777734206> `!pub` = *Afficher la publicité du serveur.*','\n','> <a:bot_good:986673556777734206> `!part_infos` = *Afficher les conditions partenariats.*','\n','> <a:bot_good:986673556777734206> `!rc` = *Afficher les conditions et les informations à propos des recrutements staff.*','\n','> <a:bot_good:986673556777734206> `!recrue` = *Donner les rôles nécessaires aux nouveaux équipiers.*','\n','> <a:bot_good:986673556777734206> `!demote_staff` = *Retirer tous les rôles d\'un staff.*','\n','> <a:bot_good:986673556777734206> `!money` = *Afficher le nombre de coins détenu(s) par un équipier.*','','','',''].join(''))))
          .setFooter(String(('Demandé par ' + String((s4dmessage.author).tag))))
                      ]
              ,components:[(new MessageActionRow()
              .addComponents(
              new MessageSelectMenu()
              .setCustomId('help-menu')
              .setPlaceholder('Interagir pour consulter les comandes')
              .setMaxValues(1)
              .setMinValues(1)
              .setDisabled(false)


              .addOptions(  {
            value:'menu_house',
            label:'Menu Principal',
            emoji:'<a:bot_house:986675888911446066>',
            description:'Retourner au menu principal',
            default:false,},
            {
            value:'menu_utils',
            label:'Utilitaire',
            emoji:'<:bot_tools:986669486461575270>',
            description:'Commandes utilitaires',
            default:false,},
            {
            value:'menu_music',
            label:'Juke-Box',
            emoji:'<:bot_radio:986669484695756830>',
            description:'Commandes de musique',
            default:false,},
            {
            value:'menu_moderator',
            label:'Modération',
            emoji:'<:bot_moderator:986669488466456636>',
            description:'Commandes de modération',
            default:false,},
            {
            value:'menu_admin',
            label:'Propriétaires',
            emoji:'<:bot_owner:986666412795920435>',
            description:'Commandes accessible seulement par les propriétaires',
            default:false,},
          ))
          )]}).then(m=>{

                      });
        }

          })

                });
  }

});

// Embed Système
s4d.client.on('messageCreate', async (s4dmessage) => {
  if ((s4dmessage.content) == String(s4d.database.get(String('prefix'))) + 'embed') {
    if ((s4dmessage.member)._roles.includes(((s4dmessage.guild).roles.cache.get('790517358548484158')).id)) {
      (s4dmessage.channel).send({
                  embeds: [new MessageEmbed()
      .setTitle(String((['<:bot_bot:986666343942213683> __**| Système d\'embed par `Business Bot','','`**__'].join(''))))
      .setColor(String(s4d.database.get(String('embed_color'))))
      .setDescription(String((['Configurez votre embed à l\'aide des différents boutons.','','','','','','',''].join(''))))
                  ]
          ,components:[(new MessageActionRow()
      .addComponents(  new MessageButton()
        .setCustomId('desc_embed')
        .setLabel('Description')
        .setEmoji('<:bot_files:986666375131058178>')
        .setStyle(('SECONDARY')),
        new MessageButton()
        .setCustomId('title_embed')
        .setLabel('Titre')
        .setEmoji('<:bot_edit:986666388494114866>')
        .setStyle(('SECONDARY')),
        new MessageButton()
        .setCustomId('color_embed')
        .setLabel('Couleur')
        .setEmoji('<:bot_captcha:986666362271322112>')
        .setStyle(('PRIMARY')),
        new MessageButton()
        .setCustomId('good_embed')
        .setEmoji('<a:bot_good:986673556777734206>')
        .setStyle(('SUCCESS')),
        new MessageButton()
        .setCustomId('notgood_embed')
        .setEmoji('<a:bot_notgood:986673549773266954>')
        .setStyle(('DANGER')),
      ))]}).then(m=>{
                        let collector = m.createMessageComponentCollector({filter: i=>i.user.id === (s4dmessage.member).id ,time:60000});
            collector.on('collect',async i=>{
                  if ((i.customId) == 'notgood_embed') {
            await i.update({ content: String('**Menu Expiré**'),components:[(new MessageActionRow()
            .addComponents(  new MessageButton()
              .setCustomId('desc_embed')
              .setLabel('Description')
              .setEmoji('<:bot_files:986666375131058178>')
              .setStyle(('SECONDARY')),
              new MessageButton()
              .setCustomId('title_embed')
              .setLabel('Titre')
              .setEmoji('<:bot_edit:986666388494114866>')
              .setStyle(('SECONDARY')),
              new MessageButton()
              .setCustomId('color_embed')
              .setLabel('Couleur')
              .setEmoji('<:bot_captcha:986666362271322112>')
              .setStyle(('PRIMARY')),
              new MessageButton()
              .setCustomId('good_embed')
              .setEmoji('<a:bot_good:986673556777734206>')
              .setStyle(('SUCCESS')),
              new MessageButton()
              .setCustomId('notgood_embed')
              .setEmoji('<a:bot_notgood:986673549773266954>')
              .setStyle(('DANGER')),
            ))]}).then(m=>{

                        });
            await i.deleteReply()
          }
          if ((i.customId) == 'good_embed') {
            (s4dmessage.channel).send({
                        embeds: [new MessageEmbed()
            .setTitle(String(s4d.database.get(String((String((s4dmessage.author).id) + 'title_embed')))))
            .setColor(String(s4d.database.get(String((String((s4dmessage.author).id) + 'color-choice_embed')))))
            .setDescription(String(s4d.database.get(String((String((s4dmessage.author).id) + 'desc_embed')))))
                        ]
                });
            await i.update({ content: String('**Menu Expiré**'),components:[(new MessageActionRow()
            .addComponents(  new MessageButton()
              .setCustomId('desc_embed')
              .setLabel('Description')
              .setEmoji('<:bot_files:986666375131058178>')
              .setStyle(('SECONDARY')),
              new MessageButton()
              .setCustomId('title_embed')
              .setLabel('Titre')
              .setEmoji('<:bot_edit:986666388494114866>')
              .setStyle(('SECONDARY')),
              new MessageButton()
              .setCustomId('color_embed')
              .setLabel('Couleur')
              .setEmoji('<:bot_captcha:986666362271322112>')
              .setStyle(('PRIMARY')),
              new MessageButton()
              .setCustomId('good_embed')
              .setEmoji('<a:bot_good:986673556777734206>')
              .setStyle(('SUCCESS')),
              new MessageButton()
              .setCustomId('notgood_embed')
              .setEmoji('<a:bot_notgood:986673549773266954>')
              .setStyle(('DANGER')),
            ))]}).then(m=>{

                        });
            await i.deleteReply()
          }
          if ((i.customId) == 'color_embed') {
            (s4dmessage.channel).send({
                        embeds: [new MessageEmbed()
            .setTitle(String(('<:bot_bot:986666343942213683> __**| Système d\'embed par `Business Bot' + '')))
            .setColor(String(s4d.database.get(String('embed_color'))))
            .setDescription(String('Choisissez parmi les couleurs ci-desous, la couleur de l\'embed.'))
                        ]
                ,components:[(new MessageActionRow()
            .addComponents(  new MessageButton()
              .setCustomId('grey_embed')
              .setLabel(' ')
              .setStyle(('SECONDARY')),
              new MessageButton()
              .setCustomId('green_embed')
              .setLabel(' ')
              .setStyle(('SUCCESS')),
              new MessageButton()
              .setCustomId('blue_embed')
              .setLabel(' ')
              .setStyle(('PRIMARY')),
              new MessageButton()
              .setCustomId('red_embed')
              .setLabel(' ')
              .setStyle(('DANGER')),
            ))]}).then(m=>{
                              let collector = m.createMessageComponentCollector({filter: i=>i.user.id === (s4dmessage.member).id ,time:60000});
                  collector.on('collect',async i=>{
                        if ((i.customId) == 'grey_embed') {
                  s4d.database.set(String((String((s4dmessage.author).id) + 'color-choice_embed')), '#52575f');
                }
                if ((i.customId) == 'green_embed') {
                  s4d.database.set(String((String((s4dmessage.author).id) + 'color-choice_embed')), '#2d7d46');
                }
                if ((i.customId) == 'blue_embed') {
                  s4d.database.set(String((String((s4dmessage.author).id) + 'color-choice_embed')), '#5865f2');
                }
                if ((i.customId) == 'red_embed') {
                  s4d.database.set(String((String((s4dmessage.author).id) + 'color-choice_embed')), '#d83c3e');
                }
                await i.update({ content: String('**Menu Expiré**'),components:[(new MessageActionRow()
                .addComponents(  new MessageButton()
                  .setCustomId('grey_embed')
                  .setLabel(' ')
                  .setStyle(('SECONDARY')),
                  new MessageButton()
                  .setCustomId('green_embed')
                  .setLabel(' ')
                  .setStyle(('SUCCESS')),
                  new MessageButton()
                  .setCustomId('blue_embed')
                  .setLabel(' ')
                  .setStyle(('PRIMARY')),
                  new MessageButton()
                  .setCustomId('red_embed')
                  .setLabel(' ')
                  .setStyle(('DANGER')),
                ))]}).then(m=>{

                            });
                await i.deleteReply()

                  })

                        });
          }
          if ((i.customId) == 'title_embed') {
            (s4dmessage.channel).send(String((['<:bot_community:986667100343001109> | Veuillez entrer le titre de l\'embed.','\n','*Entrez `cancel` pour annuler.*'].join('')))).then(() => { (s4dmessage.channel).awaitMessages({filter:(m) => m.author.id === (s4dmessage.member).id,  time: (20*60*1000), max: 1 }).then(async (collected) => { s4d.reply = collected.first().content;
             s4d.message = collected.first();
               if (!((s4d.reply) == 'cancel')) {
                s4d.database.set(String((String((s4dmessage.author).id) + 'title_embed')), (s4d.reply));
                (s4dmessage.channel).send({
                            embeds: [new MessageEmbed()
                .setTitle(String((String(s4d.database.get(String('save_emoji'))) + ' __**| Modifications sauvegardées**__')))
                .setColor(String(s4d.database.get(String('embed_color'))))
                .setDescription(String('Toutes les modifications ont bien été enregistrées !'))
                            ]
                    });
                await delay(Number(1)*1000);
                (s4dmessage.channel).bulkDelete((2|1));
              } else {
                (s4dmessage.channel).send({
                            embeds: [new MessageEmbed()
                .setTitle(String((String(s4d.database.get(String('delete_emoji'))) + ' __**| Modifications supprimées**__')))
                .setColor(String(s4d.database.get(String('embed_color'))))
                .setDescription(String('Toutes les modifications ont bien été supprimées !'))
                            ]
                    });
                (s4dmessage.channel).bulkDelete((2|1));
              }

             s4d.reply = null; }).catch(async (e) => { console.error(e);  });
            })
          }
          if ((i.customId) == 'desc_embed') {
            (s4dmessage.channel).send(String((['<:bot_community:986667100343001109> | Veuillez entrer la description de l\'embed.','\n','*Entrez `cancel` pour annuler.*'].join('')))).then(() => { (s4dmessage.channel).awaitMessages({filter:(m) => m.author.id === (s4dmessage.member).id,  time: (20*60*1000), max: 1 }).then(async (collected) => { s4d.reply = collected.first().content;
             s4d.message = collected.first();
               if (!((s4d.reply) == 'cancel')) {
                s4d.database.set(String((String((s4dmessage.author).id) + 'desc_embed')), (s4d.reply));
                (s4dmessage.channel).send({
                            embeds: [new MessageEmbed()
                .setTitle(String((String(s4d.database.get(String('save_emoji'))) + ' __**| Modifications sauvegardées**__')))
                .setColor(String(s4d.database.get(String('embed_color'))))
                .setDescription(String('Toutes les modifications ont bien été enregistrées !'))
                            ]
                    });
                await delay(Number(1)*1000);
                (s4dmessage.channel).bulkDelete((2|1));
              } else {
                (s4dmessage.channel).send({
                            embeds: [new MessageEmbed()
                .setTitle(String((String(s4d.database.get(String('delete_emoji'))) + ' __**| Modifications supprimées**__')))
                .setColor(String(s4d.database.get(String('embed_color'))))
                .setDescription(String('Toutes les modifications ont bien été supprimées !'))
                            ]
                    });
                (s4dmessage.channel).bulkDelete((2|1));
              }

             s4d.reply = null; }).catch(async (e) => { console.error(e);  });
            })
          }

            })

                  });
    } else {
      s4dmessage.reply({
                  embeds: [new MessageEmbed()
      .setTitle(String((String(s4d.database.get(String('noaccess_emoji'))) + ' **| Une erreur est survenue !**')))
      .setColor(String(s4d.database.get(String('embed_color'))))
      .setDescription(String('Pour poursuivre, vous devez posséder le rôle *<@&790517358548484158>*.'))
                  ]
          , allowedMentions: {
              repliedUser: true
          }}).then(async (s4dfrost_real_reply) =>{
         await delay(Number(3)*1000);
        s4dfrost_real_reply.delete();
        s4dmessage.delete();

      });
    }
  }

});

// Compteurs
s4d.client.on('messageCreate', async (s4dmessage) => {
  if ((s4dmessage.content) == String(s4d.database.get(String('prefix'))) + 'member_count') {
    s4dmessage.reply({
                embeds: [new MessageEmbed()
    .setTitle(String((String(s4d.database.get(String('infos_emoji'))) + '** | Nombre de membres**')))
    .setColor(String(s4d.database.get(String('embed_color'))))
    .setDescription(String((['Le serveur possède `',(s4dmessage.guild).members.cache.filter(m => !m.user.bot).size,'` membre(s) !'].join(''))))
    .setFooter(String(('Demandé par ' + String((s4dmessage.author).tag))))
                ]
        , allowedMentions: {
            repliedUser: true
        }});
  }
  if ((s4dmessage.content) == String(s4d.database.get(String('prefix'))) + 'bot_count') {
    s4dmessage.reply({
                embeds: [new MessageEmbed()
    .setTitle(String((String(s4d.database.get(String('infos_emoji'))) + '** | Nombre de bots**')))
    .setColor(String(s4d.database.get(String('embed_color'))))
    .setDescription(String((['Le serveur possède `',(s4dmessage.guild).members.cache.filter(m => m.user.bot).size,'` bot(s) !'].join(''))))
    .setFooter(String(('Demandé par ' + String((s4dmessage.author).tag))))
                ]
        , allowedMentions: {
            repliedUser: true
        }});
  }
  if ((s4dmessage.content) == String(s4d.database.get(String('prefix'))) + 'chanel_count') {
    s4dmessage.reply({
                embeds: [new MessageEmbed()
    .setTitle(String((String(s4d.database.get(String('infos_emoji'))) + '** | Nombre de salons**')))
    .setColor(String(s4d.database.get(String('embed_color'))))
    .setDescription(String((['Le serveur possède `',(s4dmessage.guild).channels.cache.size,'` salon(s) !'].join(''))))
    .setFooter(String(('Demandé par ' + String((s4dmessage.author).tag))))
                ]
        , allowedMentions: {
            repliedUser: true
        }});
  }
  if ((s4dmessage.content) == String(s4d.database.get(String('prefix'))) + 'pub_count') {
    s4dmessage.reply({
                embeds: [new MessageEmbed()
    .setTitle(String((String(s4d.database.get(String('infos_emoji'))) + '** | Nombre de publicités**')))
    .setColor(String(s4d.database.get(String('embed_color'))))
    .setDescription(String((['Le serveur possède `',s4d.database.get(String('total_pub')),'` publicité(s) !'].join(''))))
    .setFooter(String(('Demandé par ' + String((s4dmessage.author).tag))))
                ]
        , allowedMentions: {
            repliedUser: true
        }});
  }
  if ((s4dmessage.content) == String(s4d.database.get(String('prefix'))) + 'ping') {
    s4dmessage.reply({
                embeds: [new MessageEmbed()
    .setTitle(String((String(s4d.database.get(String('infos_emoji'))) + '** | Ping**')))
    .setColor(String(s4d.database.get(String('embed_color'))))
    .setDescription(String((['Mon ping est de `',s4d.client.ws.ping,'` ms !'].join(''))))
    .setFooter(String(('Demandé par ' + String((s4dmessage.author).tag))))
                ]
        , allowedMentions: {
            repliedUser: true
        }});
  }

});

s4d.client.on('messageDelete', async (s4dmessage) => {
  s4d.client.channels.cache.get(s4d.database.get(String('logs_bot'))).send({
              embeds: [new MessageEmbed()
  .setTitle(String((String(s4d.database.get(String('delete_emoji'))) + '** | Message supprimé**')))
  .setColor(String(s4d.database.get(String('embed_color'))))
  .setDescription(String((['**<a:bot_loupe:986674310913617920> | Salon:** `#',(s4dmessage.channel).name,' | ',(s4dmessage.channel).id,' | ',(s4dmessage.channel).parentId,'`','\n','\n','**<:bot_edit:986666388494114866> | Contenu:** ','\n','\n',s4dmessage.content,'\n','\n','**<:bot_community:986667100343001109> | Utilisateur:** ```',(s4dmessage.member.user).id,'```'].join(''))))
  .setFooter(String(('Message posté par ' + String((s4dmessage.member.user).tag))))
  .setThumbnail(String(((s4dmessage.member.user).displayAvatarURL({format:"png"}))))
              ]
      });

});

s4d.client.on('messageCreate', async (s4dmessage) => {
  if ((s4dmessage.content) == String(s4d.database.get(String('prefix'))) + 'xp') {
    s4dmessage.reply({
                embeds: [new MessageEmbed()
    .setTitle(String((String(s4d.database.get(String('level_emoji'))) + '** | XP**')))
    .setColor(String(s4d.database.get(String('embed_color'))))
    .setDescription(String((['Vous avez atteint les `',s4d.database.get(String((String((s4dmessage.author).id) + '-xp'))),'/500`XP !'].join(''))))
    .setFooter(String(('Demandé par ' + String((s4dmessage.author).tag))))
                ]
        , allowedMentions: {
            repliedUser: true
        }});
  }
  if (((s4dmessage.content) || '').startsWith((String(s4d.database.get(String('prefix'))) + 'xp') || '')) {
    xp_args = (s4dmessage.content).split(' ');
    xp = xp_args.splice(1, 1)[0];
    if ((level || '').startsWith('<@' || '')) {
      if (!s4d.database.has(String((String((s4dmessage.mentions.members.first().user).id) + '-xp')))) {
        s4d.database.set(String((String((s4dmessage.mentions.members.first().user).id) + '-xp')), '0');
        s4dmessage.reply({
                    embeds: [new MessageEmbed()
        .setTitle(String((String(s4d.database.get(String('level_emoji'))) + '** | XP**')))
        .setColor(String(s4d.database.get(String('embed_color'))))
        .setDescription(String(([(s4dmessage.mentions.members.first().user).username,' a atteint les `',s4d.database.get(String((String((s4dmessage.mentions.members.first().user).id) + '-xp'))),'/500`XP !'].join(''))))
        .setFooter(String(('Demandé par ' + String((s4dmessage.author).tag))))
                    ]
            , allowedMentions: {
                repliedUser: true
            }});
      } else {
        s4dmessage.reply({
                    embeds: [new MessageEmbed()
        .setTitle(String((String(s4d.database.get(String('level_emoji'))) + '** | XP**')))
        .setColor(String(s4d.database.get(String('embed_color'))))
        .setDescription(String(([(s4dmessage.mentions.members.first().user).username,' a atteint les `',s4d.database.get(String((String((s4dmessage.mentions.members.first().user).id) + '-xp'))),'/500`XP !'].join(''))))
        .setFooter(String(('Demandé par ' + String((s4dmessage.author).tag))))
                    ]
            , allowedMentions: {
                repliedUser: true
            }});
      }
    } else {
      if (!s4d.database.has(String((String(level) + '-xp')))) {
        s4d.database.set(String((String(level) + '-xp')), '0');
        s4dmessage.reply({
                    embeds: [new MessageEmbed()
        .setTitle(String((String(s4d.database.get(String('level_emoji'))) + '** | XP**')))
        .setColor(String(s4d.database.get(String('embed_color'))))
        .setDescription(String(([(((s4dmessage.guild).members.cache.get(level) || await (s4dmessage.guild).members.fetch(level)).user).username,' a atteint les `',s4d.database.get(String((String(level) + '-xp'))),'/500`XP !'].join(''))))
        .setFooter(String(('Demandé par ' + String((s4dmessage.author).tag))))
                    ]
            , allowedMentions: {
                repliedUser: true
            }});
      } else {
        s4dmessage.reply({
                    embeds: [new MessageEmbed()
        .setTitle(String((String(s4d.database.get(String('level_emoji'))) + '** | XP**')))
        .setColor(String(s4d.database.get(String('embed_color'))))
        .setDescription(String(([(((s4dmessage.guild).members.cache.get(level) || await (s4dmessage.guild).members.fetch(level)).user).username,' a atteint les `',s4d.database.get(String((String(level) + '-level'))),'/500`XP !'].join(''))))
        .setFooter(String(('Demandé par ' + String((s4dmessage.author).tag))))
                    ]
            , allowedMentions: {
                repliedUser: true
            }});
      }
    }
  }
  if ((s4dmessage.content) == String(s4d.database.get(String('prefix'))) + 'level') {
    s4dmessage.reply({
                embeds: [new MessageEmbed()
    .setTitle(String((String(s4d.database.get(String('level_emoji'))) + '** | Niveau**')))
    .setColor(String(s4d.database.get(String('embed_color'))))
    .setDescription(String((['Vous avez atteint le niveau `',s4d.database.get(String((String((s4dmessage.author).id) + '-level'))),'` !'].join(''))))
    .setFooter(String(('Demandé par ' + String((s4dmessage.author).tag))))
                ]
        , allowedMentions: {
            repliedUser: true
        }});
  }
  if (((s4dmessage.content) || '').startsWith((String(s4d.database.get(String('prefix'))) + 'level') || '')) {
    level_args = (s4dmessage.content).split(' ');
    level = level_args.splice(1, 1)[0];
    if ((level || '').startsWith('<@' || '')) {
      if (!s4d.database.has(String((String((s4dmessage.mentions.members.first().user).id) + '-level')))) {
        s4d.database.set(String((String((s4dmessage.mentions.members.first().user).id) + '-level')), '0');
        s4dmessage.reply({
                    embeds: [new MessageEmbed()
        .setTitle(String((String(s4d.database.get(String('level_emoji'))) + '** | Niveau**')))
        .setColor(String(s4d.database.get(String('embed_color'))))
        .setDescription(String(([(s4dmessage.mentions.members.first().user).username,' a atteint le niveau `',s4d.database.get(String((String((s4dmessage.mentions.members.first().user).id) + '-level'))),'` !'].join(''))))
        .setFooter(String(('Demandé par ' + String((s4dmessage.author).tag))))
                    ]
            , allowedMentions: {
                repliedUser: true
            }});
      } else {
        s4dmessage.reply({
                    embeds: [new MessageEmbed()
        .setTitle(String((String(s4d.database.get(String('level_emoji'))) + '** | Niveau**')))
        .setColor(String(s4d.database.get(String('embed_color'))))
        .setDescription(String(([(s4dmessage.mentions.members.first().user).username,' a atteint le niveau `',s4d.database.get(String((String((s4dmessage.mentions.members.first().user).id) + '-level'))),'` !'].join(''))))
        .setFooter(String(('Demandé par ' + String((s4dmessage.author).tag))))
                    ]
            , allowedMentions: {
                repliedUser: true
            }});
      }
    } else {
      if (!s4d.database.has(String((String(level) + '-level')))) {
        s4d.database.set(String((String(level) + '-level')), '0');
        s4dmessage.reply({
                    embeds: [new MessageEmbed()
        .setTitle(String((String(s4d.database.get(String('level_emoji'))) + '** | Niveau**')))
        .setColor(String(s4d.database.get(String('embed_color'))))
        .setDescription(String(([(((s4dmessage.guild).members.cache.get(level) || await (s4dmessage.guild).members.fetch(level)).user).username,' a atteint le niveau `',s4d.database.get(String((String(level) + '-level'))),'` !'].join(''))))
        .setFooter(String(('Demandé par ' + String((s4dmessage.author).tag))))
                    ]
            , allowedMentions: {
                repliedUser: true
            }});
      } else {
        s4dmessage.reply({
                    embeds: [new MessageEmbed()
        .setTitle(String((String(s4d.database.get(String('level_emoji'))) + '** | Niveau**')))
        .setColor(String(s4d.database.get(String('embed_color'))))
        .setDescription(String(([(((s4dmessage.guild).members.cache.get(level) || await (s4dmessage.guild).members.fetch(level)).user).username,' a atteint le niveau `',s4d.database.get(String((String(level) + '-level'))),'` !'].join(''))))
        .setFooter(String(('Demandé par ' + String((s4dmessage.author).tag))))
                    ]
            , allowedMentions: {
                repliedUser: true
            }});
      }
    }
  }

});

// level système
s4d.client.on('messageCreate', async (s4dmessage) => {
  s4d.database.add(String((String((s4dmessage.author).id) + '-xp')), parseInt(10));
  if (s4d.database.get(String((String((s4dmessage.author).id) + '-xp'))) >= '500') {
    s4d.database.add(String((String((s4dmessage.author).id) + '-level')), parseInt(1));
    s4d.database.subtract(String((String((s4dmessage.author).id) + '-xp')), parseInt(500));
    s4d.client.channels.cache.get(s4d.database.get(String('lvl_chanel'))).send({
                embeds: [new MessageEmbed()
    .setTitle(String((String(s4d.database.get(String('level_emoji'))) + '** | Félicitations**')))
    .setColor(String(s4d.database.get(String('embed_color'))))
    .setDescription(String((['Bravo à <@',(s4dmessage.author).id,'','>, il a atteint le niveau `',s4d.database.get(String((String((s4dmessage.author).id) + '-level'))),'` !'].join(''))))
                ]
        });
    s4d.client.channels.cache.get(s4d.database.get(String('lvl_chanel'))).send({content:String((['<@',(s4dmessage.author).id,'>'].join('')))});
    await delay(Number(1)*1000);
    s4d.client.channels.cache.get(s4d.database.get(String('lvl_chanel'))).bulkDelete((1|1));
  }

});

                    return s4d
                    })();