(async()=>{
                let process = require('process');
                process.on('uncaughtException', function (err) {
                    console.log(`Error!`);
                    console.log(err);
                  });
                                  const ShsHSjJSjSJSJSGHkkhdjdmns = ['CREATE_INSTANT_INVITE','MANAGE_CHANNELS','ADD_REACTIONS','STREAM','VIEW_CHANNEL','SEND_MESSAGES','SEND_TTS_MESSAGES','MANAGE_MESSAGES','EMBED_LINKS','ATTACH_FILES','READ_MESSAGE_HISTORY','MENTION_EVERYONE','USE_EXTERNAL_EMOJIS','CONNECT','SPEAK','USE_VAD','CHANGE_NICKNAME','MANAGE_ROLES','MANAGE_WEBHOOKS','USE_APPLICATION_COMMANDS','REQUEST_TO_SPEAK','MANAGE_THREADS','USE_PUBLIC_THREADS','CREATE_PUBLIC_THREADS','USE_PRIVATE_THREADS','CREATE_PRIVATE_THREADS','USE_EXTERNAL_STICKERS','SEND_MESSAGES_IN_THREADS','START_EMBEDDED_ACTIVITIES'
                         
                         
     
     
     
             
             
     
     
     
                         
                         ]
                  const events = require('events');
                  const { exec } = require("child_process")
                  const S4D_APP_RUN_BUTTON = false
                  let Discord = require("discord.js")
let Database  = require("easy-json-database")
let { MessageEmbed, MessageButton, MessageActionRow, Intents, Permissions, MessageSelectMenu }= require("discord.js")
let logs = require("discord-logs")
const os = require("os-utils");
const ms = require("ms")
const Captcha = require("@haileybot/captcha-generator");
let fs = require('fs');
                    const devMode = typeof __E_IS_DEV !== "undefined" && __E_IS_DEV;
                    const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
                    const s4d = {
                        Discord,
                        database: new Database(`./database.json`),
fire:null,
                        joiningMember:null,
                        reply:null,
                        tokenInvalid:false,
                        tokenError: null,
                        player:null,
                        manager:null,
                        Inviter:null,
                        message:null,
                        notifer:null,
                        checkMessageExists() {
                            if (!s4d.client) throw new Error('You cannot perform message operations without a Discord.js client')
                            if (!s4d.client.readyTimestamp) throw new Error('You cannot perform message operations while the bot is not connected to the Discord API')
                        }
                    };
                    s4d.client = new s4d.Discord.Client({
                    intents: [Object.values(s4d.Discord.Intents.FLAGS).reduce((acc, p) => acc | p, 0)],
                    partials: ["REACTION", "CHANNEL"]
                    });
                    s4d.client.on('ready', () => {
                        console.log(s4d.client.user.tag + " is alive!")
                    })
                    logs(s4d.client);         
                    var ban_member_args, xp_args, ban_member, sperso_resp, xp, ban_member_id, sperso_resp2, level_args, ban_reason, level;


await s4d.client.login('ODc1NjUyMDk1NDgxNjIyNTk4.GlWdJP.6La_-qS9bHbYJXpKNhIFOH8B4eWXCogJtYJ1wI').catch((e) => {
        s4d.tokenInvalid = true;
        s4d.tokenError = e;
        if (e.toString().toLowerCase().includes("token")) {
            throw new Error("An invalid token was provided!")
        } else {
            throw new Error("Intents are not turned on!")
        }
    });

// ban id system
s4d.client.on('guildMemberAdd', async (param1) => {
s4d.joiningMember = param1;
  if (s4d.database.get(String((s4d.joiningMember.id))) == 'banned') {
    (s4d.joiningMember).ban({ reason: ('[Business Bot] ' + String(s4d.database.get(String((String(s4d.joiningMember.id) + '-ban_reason'))).join(' '))) });
  }
s4d.joiningMember = null
});

// moderation command
s4d.client.on('messageCreate', async (s4dmessage) => {
  if (((s4dmessage.content) || '').startsWith((String(s4d.database.get(String('prefix'))) + 'ban') || '')) {
    if ((s4dmessage.member).permissions.has(Permissions.FLAGS.ADMINISTRATOR) || ((s4dmessage.member)._roles.includes(((s4dmessage.guild).roles.cache.find((role) => role.name === s4d.database.get(String('ban_perm1')))).id)) || ((s4dmessage.member)._roles.includes(((s4dmessage.guild).roles.cache.find((role) => role.name === s4d.database.get(String('ban_perm2')))).id)) || ((s4dmessage.member)._roles.includes(((s4dmessage.guild).roles.cache.find((role) => role.name === s4d.database.get(String('ban_perm3')))).id)) || ((s4dmessage.member)._roles.includes(((s4dmessage.guild).roles.cache.find((role) => role.name === s4d.database.get(String('ban_perm4')))).id)) || ((s4dmessage.member)._roles.includes(((s4dmessage.guild).roles.cache.find((role) => role.name === s4d.database.get(String('ban_perm5')))).id)) || ((s4dmessage.member)._roles.includes(((s4dmessage.guild).roles.cache.find((role) => role.name === s4d.database.get(String('ban_perm5')))).id)) || ((s4dmessage.member)._roles.includes(((s4dmessage.guild).roles.cache.find((role) => role.name === s4d.database.get(String('ban_perm6')))).id)) || ((s4dmessage.member)._roles.includes(((s4dmessage.guild).roles.cache.find((role) => role.name === s4d.database.get(String('ban_perm')))).id))) {
      ban_member_args = (s4dmessage.content).split(' ');
      ban_member = ban_member_args.splice(1, 1)[0];
      ban_member_id = ban_member.slice(0, 21);
      ban_reason = ban_member_args.slice(1, 10000000);
      if ((ban_member || '').startsWith('<@' || '')) {
        s4dmessage.reply({
                    embeds: [new MessageEmbed()
        .setTitle(String((String(s4d.database.get(String('banned_emoji'))) + '__** | Utilisateur sanctionné !**__')))
        .setColor(String(s4d.database.get(String('embed_color'))))
        .setDescription(String((['L\'utilisateur a bien été sanctionné !','\n','\n','<a:bot_loupe:986674310913617920> **| Type de sanction:** ```','Bannissement ```','\n','','<:bot_edit:986666388494114866> **| Raison:** ```',ban_reason.join(' '),'```',''].join(''))))
        .setFooter(String(('Demandé par ' + String((s4dmessage.author).tag))))
                    ]
            , allowedMentions: {
                repliedUser: true
            }});
        (s4dmessage.mentions.members.first()).send({
                    embeds: [new MessageEmbed()
        .setTitle(String(([s4d.database.get(String('banned_emoji')),'__** | Vous avez reçu une sanction**__','',''].join(''))))
        .setColor(String(s4d.database.get(String('embed_color'))))
        .setDescription(String((['Vous avez reçu une sanction sûr `',(s4dmessage.guild).name,'` !','\n','\n','<a:bot_loupe:986674310913617920> **| Type de sanction:** ```','Bannissement ```','\n','','<:bot_edit:986666388494114866> **| Raison:** ```',ban_reason.join(' '),'```','\n','<:bot_shield:986666382735339550> **| Auteur:** ```',(s4dmessage.author).tag,'```'].join(''))))
                    ]
            });
        s4d.client.channels.cache.get(s4d.database.get(String('logs_bot'))).send({
                    embeds: [new MessageEmbed()
        .setTitle(String(([s4d.database.get(String('banned_emoji')),'__** | Nouvelle sanction**__','',''].join(''))))
        .setColor(String(s4d.database.get(String('embed_color'))))
        .setDescription(String((['<:bot_handcuffs:986666403144818758> **| Utilisateur:** ```',(s4dmessage.mentions.members.first().user).tag,' / ',ban_member_id,'```','\n','<a:bot_loupe:986674310913617920> **| Type de sanction:** ```','Bannissement ```','\n','','<:bot_edit:986666388494114866> **| Raison:** ```',ban_reason.join(' '),'```','\n','<:bot_shield:986666382735339550> **| Auteur:** ```',(s4dmessage.author).tag,'```'].join(''))))
                    ]
            });
        (s4dmessage.mentions.members.first()).ban({ reason: ('[Business Bot] ' + String(ban_reason.join(' '))) });
      } else {
        s4d.database.set(String(ban_member_id), 'banned');
        s4d.database.set(String((String(ban_member_id) + '-ban_reason')), ban_reason);
        s4d.database.set(String((String(ban_member_id) + '-ban_author')), ((s4dmessage.author).tag));
        s4dmessage.reply({
                    embeds: [new MessageEmbed()
        .setTitle(String((String(s4d.database.get(String('banned_emoji'))) + '__** | Utilisateur sanctionné !**__')))
        .setColor(String(s4d.database.get(String('embed_color'))))
        .setDescription(String((['L\'utilisateur a bien été sanctionné !','\n','\n','<a:bot_loupe:986674310913617920> **| Type de sanction:** ```','Bannissement ```','\n','','<:bot_edit:986666388494114866> **| Raison:** ```',ban_reason.join(' '),'```',''].join(''))))
        .setFooter(String(('Demandé par ' + String((s4dmessage.author).tag))))
                    ]
            , allowedMentions: {
                repliedUser: true
            }});
        s4d.client.channels.cache.get(s4d.database.get(String('logs_bot'))).send({
                    embeds: [new MessageEmbed()
        .setTitle(String(([s4d.database.get(String('banned_emoji')),'__** | Nouvelle sanction**__','',''].join(''))))
        .setColor(String(s4d.database.get(String('embed_color'))))
        .setDescription(String((['<:bot_handcuffs:986666403144818758> **| Utilisateur:** ```','',ban_member_id,'','```','\n','<a:bot_loupe:986674310913617920> **| Type de sanction:** ```','Bannissement ```','\n','','<:bot_edit:986666388494114866> **| Raison:** ```',ban_reason.join(' '),'```','\n','<:bot_shield:986666382735339550> **| Auteur:** ```',(s4dmessage.author).tag,'```'].join(''))))
                    ]
            });
        (((s4dmessage.guild).members.cache.get(ban_member_id) || await (s4dmessage.guild).members.fetch(ban_member_id))).send({
                    embeds: [new MessageEmbed()
        .setTitle(String(([s4d.database.get(String('banned_emoji')),'__** | Vous avez reçu une sanction**__','',''].join(''))))
        .setColor(String(s4d.database.get(String('embed_color'))))
        .setDescription(String((['Vous avez reçu une sanction sûr `',(s4dmessage.guild).name,'` !','\n','\n','<a:bot_loupe:986674310913617920> **| Type de sanction:** ```','Bannissement ```','\n','','<:bot_edit:986666388494114866> **| Raison:** ```',ban_reason.join(' '),'```','\n','<:bot_shield:986666382735339550> **| Auteur:** ```',(s4dmessage.author).tag,'```'].join(''))))
                    ]
            });
        (((s4dmessage.guild).members.cache.get(ban_member_id) || await (s4dmessage.guild).members.fetch(ban_member_id))).ban({ reason: ('[Business Bot] ' + String(ban_reason.join(' '))) });
      }
    } else {
      s4dmessage.reply({
                  embeds: [new MessageEmbed()
      .setTitle(String((String(s4d.database.get(String('noaccess_emoji'))) + '__** | Un erreur s\'est produite !**__')))
      .setColor(String(s4d.database.get(String('embed_color'))))
      .setDescription(String(('Vous n\'avez pas l\'autorisation d\'entrer cette commande !' + '')))
      .setFooter(String(('Demandé par ' + String((s4dmessage.author).tag))))
                  ]
          , allowedMentions: {
              repliedUser: true
          }}).then(async (s4dfrost_real_reply) =>{
         await delay(Number(5)*1000);
        s4dfrost_real_reply.delete();
        s4dmessage.delete();

      });
    }
  }
  if (((s4dmessage.content) || '').startsWith((String(s4d.database.get(String('prefix'))) + 'kick') || '')) {
    if ((s4dmessage.member).permissions.has(Permissions.FLAGS.ADMINISTRATOR) || ((s4dmessage.member)._roles.includes(((s4dmessage.guild).roles.cache.find((role) => role.name === s4d.database.get(String('ban_perm1')))).id)) || ((s4dmessage.member)._roles.includes(((s4dmessage.guild).roles.cache.find((role) => role.name === s4d.database.get(String('ban_perm2')))).id)) || ((s4dmessage.member)._roles.includes(((s4dmessage.guild).roles.cache.find((role) => role.name === s4d.database.get(String('ban_perm3')))).id)) || ((s4dmessage.member)._roles.includes(((s4dmessage.guild).roles.cache.find((role) => role.name === s4d.database.get(String('ban_perm4')))).id)) || ((s4dmessage.member)._roles.includes(((s4dmessage.guild).roles.cache.find((role) => role.name === s4d.database.get(String('ban_perm5')))).id)) || ((s4dmessage.member)._roles.includes(((s4dmessage.guild).roles.cache.find((role) => role.name === s4d.database.get(String('ban_perm5')))).id)) || ((s4dmessage.member)._roles.includes(((s4dmessage.guild).roles.cache.find((role) => role.name === s4d.database.get(String('ban_perm6')))).id)) || ((s4dmessage.member)._roles.includes(((s4dmessage.guild).roles.cache.find((role) => role.name === s4d.database.get(String('ban_perm')))).id))) {
      ban_member_args = (s4dmessage.content).split(' ');
      ban_member = ban_member_args.splice(1, 1)[0];
      ban_member_id = ban_member.slice(0, 20);
      ban_reason = ban_member_args.slice(1, 10000000);
      if ((ban_member || '').startsWith('<@' || '')) {
        s4dmessage.reply({
                    embeds: [new MessageEmbed()
        .setTitle(String((String(s4d.database.get(String('banned_emoji'))) + '__** | Utilisateur sanctionné !**__')))
        .setColor(String(s4d.database.get(String('embed_color'))))
        .setDescription(String((['L\'utilisateur a bien été sanctionné !','\n','\n','<a:bot_loupe:986674310913617920> **| Type de sanction:** ```','Expulsion```','\n','','<:bot_edit:986666388494114866> **| Raison:** ```',ban_reason.join(' '),'```',''].join(''))))
        .setFooter(String(('Demandé par ' + String((s4dmessage.author).tag))))
                    ]
            , allowedMentions: {
                repliedUser: true
            }});
        s4d.client.channels.cache.get(s4d.database.get(String('logs_bot'))).send({
                    embeds: [new MessageEmbed()
        .setTitle(String(([s4d.database.get(String('banned_emoji')),'__** | Nouvelle sanction**__','',''].join(''))))
        .setColor(String(s4d.database.get(String('embed_color'))))
        .setDescription(String((['<:bot_handcuffs:986666403144818758> **| Utilisateur:** ```',(s4dmessage.mentions.members.first().user).tag,' / ',(s4dmessage.mentions.members.first().user).id,'```','\n','<a:bot_loupe:986674310913617920> **| Type de sanction:** ```','Expulsion```','\n','','<:bot_edit:986666388494114866> **| Raison:** ```',ban_reason.join(' '),'```','\n','<:bot_shield:986666382735339550> **| Auteur:** ```',(s4dmessage.author).tag,'```'].join(''))))
                    ]
            });
        (s4dmessage.mentions.members.first()).send({
                    embeds: [new MessageEmbed()
        .setTitle(String(([s4d.database.get(String('banned_emoji')),'__** | Vous avez reçu une sanction**__','',''].join(''))))
        .setColor(String(s4d.database.get(String('embed_color'))))
        .setDescription(String((['Vous avez reçu une sanction sûr `',(s4dmessage.guild).name,'` !','\n','\n','<a:bot_loupe:986674310913617920> **| Type de sanction:** ```','Expulsion ```','\n','','<:bot_edit:986666388494114866> **| Raison:** ```',ban_reason.join(' '),'```','\n','<:bot_shield:986666382735339550> **| Auteur:** ```',(s4dmessage.author).tag,'```'].join(''))))
                    ]
            });
        (s4dmessage.mentions.members.first()).kick({ reason: ('[Business Bot] ' + String(ban_reason.join(' '))) });
      } else {
        s4d.client.channels.cache.get(s4d.database.get(String('logs_bot'))).send({
                    embeds: [new MessageEmbed()
        .setTitle(String(([s4d.database.get(String('banned_emoji')),'__** | Nouvelle sanction**__','',''].join(''))))
        .setColor(String(s4d.database.get(String('embed_color'))))
        .setDescription(String((['<:bot_handcuffs:986666403144818758> **| Utilisateur:** ```',(((s4dmessage.guild).members.cache.get(ban_member_id) || await (s4dmessage.guild).members.fetch(ban_member_id)).user).tag,' / ',ban_member_id,'```','\n','<a:bot_loupe:986674310913617920> **| Type de sanction:** ```','Expulsion```','\n','','<:bot_edit:986666388494114866> **| Raison:** ```',ban_reason.join(' '),'```','\n','<:bot_shield:986666382735339550> **| Auteur:** ```',(s4dmessage.author).tag,'```'].join(''))))
                    ]
            });
        s4dmessage.reply({
                    embeds: [new MessageEmbed()
        .setTitle(String((String(s4d.database.get(String('banned_emoji'))) + '__** | Utilisateur sanctionné !**__')))
        .setColor(String(s4d.database.get(String('embed_color'))))
        .setDescription(String((['L\'utilisateur a bien été sanctionné !','\n','\n','<a:bot_loupe:986674310913617920> **| Type de sanction:** ```','Bannissement ```','\n','','<:bot_edit:986666388494114866> **| Raison:** ```',ban_reason.join(' '),'```',''].join(''))))
        .setFooter(String(('Demandé par ' + String((s4dmessage.author).tag))))
                    ]
            , allowedMentions: {
                repliedUser: true
            }});
        (((s4dmessage.guild).members.cache.get(ban_member_id) || await (s4dmessage.guild).members.fetch(ban_member_id))).send({
                    embeds: [new MessageEmbed()
        .setTitle(String(([s4d.database.get(String('banned_emoji')),'__** | Vous avez reçu une sanction**__','',''].join(''))))
        .setColor(String(s4d.database.get(String('embed_color'))))
        .setDescription(String((['Vous avez reçu une sanction sûr `',(s4dmessage.guild).name,'` !','\n','\n','<a:bot_loupe:986674310913617920> **| Type de sanction:** ```','Expulsion ```','\n','','<:bot_edit:986666388494114866> **| Raison:** ```',ban_reason.join(' '),'```','\n','<:bot_shield:986666382735339550> **| Auteur:** ```',(s4dmessage.author).tag,'```'].join(''))))
                    ]
            });
        (((s4dmessage.guild).members.cache.get(ban_member_id) || await (s4dmessage.guild).members.fetch(ban_member_id))).kick({ reason: ('[Business Bot] ' + String(ban_reason.join(' '))) });
      }
    } else {
      s4dmessage.reply({
                  embeds: [new MessageEmbed()
      .setTitle(String((String(s4d.database.get(String('noaccess_emoji'))) + '__** | Un erreur s\'est produite !**__')))
      .setColor(String(s4d.database.get(String('embed_color'))))
      .setDescription(String(('Vous n\'avez pas l\'autorisation d\'entrer cette commande !' + '')))
      .setFooter(String(('Demandé par ' + String((s4dmessage.author).tag))))
                  ]
          , allowedMentions: {
              repliedUser: true
          }}).then(async (s4dfrost_real_reply) =>{
         await delay(Number(5)*1000);
        s4dfrost_real_reply.delete();
        s4dmessage.delete();

      });
    }
  }

});

s4d.client.on('messageCreate', async (s4dmessage) => {
  if (((s4dmessage.content) || '').startsWith((String(s4d.database.get(String('prefix'))) + 'sperso') || '')) {
    if (!((s4dmessage.content) == String(s4d.database.get(String('prefix'))) + 'sperso')) {
      if ((s4dmessage.member)._roles.includes(((s4dmessage.guild).roles.cache.get('790517358548484158')).id)) {
        sperso_resp = (s4dmessage.content).split(' ');
        sperso_resp2 = sperso_resp.splice(1, 1)[0];
        s4d.database.set(String(('' + 'resp-id')), sperso_resp2);
        s4d.database.set(String(((s4dmessage.author).id)), s4d.database.get(String('resp-id')));
        (s4dmessage.channel).send({
                    embeds: [new MessageEmbed()
        .setTitle(String((String(s4d.database.get(String('settings_emoji'))) + ' | Création de salon personnalisé')))
        .setColor(String(s4d.database.get(String('embed_color'))))
        .setDescription(String('Configurez le nouveau salon personnalisé à l\'aide des boutons.'))
                    ]
            ,components:[(new MessageActionRow()
            .addComponents(
            new MessageSelectMenu()
            .setCustomId('s_perso')
            .setPlaceholder('Menu de configuration')
            .setMaxValues(1)
            .setMinValues(1)
            .setDisabled(false)


            .addOptions(  {
          value:'name_sp',
          label:'Nom du salon',
          emoji:'<:bot_files:986666375131058178>',
          description:'Configurer le nom du salon.',
          default:false,},
          {
          value:'time_sp',
          label:'Temps du salon',
          emoji:'<:bot_timedout:986666367656788038>',
          description:'Configurer le temps du salon.',
          default:false,},
          {
          value:'ping_sp',
          label:'Mention',
          emoji:'<:bot_muted:986666385763627078>',
          description:'Configurer la mention du salon.',
          default:false,},
          {
          value:'reason_sp',
          label:'Raison du salon',
          emoji:'<:bot_edit:986666388494114866>',
          description:'Configurer la raison du salon.',
          default:false,},
          {
          value:'pub_sp',
          label:'Publicité du serveur',
          emoji:'<:bot_captcha:986666362271322112>',
          description:'Configurer la publicité du salon.',
          default:false,},
          {
          value:'ok',
          label:'Terminer',
          emoji:'<a:bot_good:986673556777734206>',
          description:'Continuer la configuration.',
          default:false,},
        ))
        )]}).then(m=>{
                          let collector = m.createMessageComponentCollector({filter: i=>i.user.id === (s4dmessage.member).id ,time:60000});
              collector.on('collect',async i=>{
                    if ((i.customId) == 's_perso' && (i.values[0]) == 'name_sp') {
              (s4dmessage.channel).send(String(([s4d.database.get(String('question_emoji')),'**| Quel est le nom du salon personnalisé ?**','\n','*Entrez `cancel` pour annuler.*'].join('')))).then(() => { (s4dmessage.channel).awaitMessages({filter:(m) => m.author.id === (s4dmessage.author).id,  time: (15*60*1000), max: 1 }).then(async (collected) => { s4d.reply = collected.first().content;
               s4d.message = collected.first();
                 if (!((s4d.reply) == 'cancel')) {
                  s4d.database.set(String((String(s4d.database.get(String(((s4dmessage.author).id)))) + '-name')), (s4d.reply));
                  (s4dmessage.channel).send({
                              embeds: [new MessageEmbed()
                  .setTitle(String((String(s4d.database.get(String('good_emoji'))) + ' | Tout est bon !')))
                  .setColor(String(s4d.database.get(String('embed_color'))))
                  .setDescription(String('Votre choix a bien été sauvegardé !'))
                              ]
                      });
                  await delay(Number(2)*1000);
                  (s4dmessage.channel).bulkDelete((3|1));
                }

               s4d.reply = null; }).catch(async (e) => { console.error(e);  });
              })
            }
            if ((i.customId) == 's_perso' && (i.values[0]) == 'pub_sp') {
              (s4dmessage.channel).send(String(([s4d.database.get(String('question_emoji')),'**| Quelle est la publicité du serveur en question ?**','\n','*Entrez `cancel` pour annuler.*'].join('')))).then(() => { (s4dmessage.channel).awaitMessages({filter:(m) => m.author.id === (s4dmessage.author).id,  time: (15*60*1000), max: 1 }).then(async (collected) => { s4d.reply = collected.first().content;
               s4d.message = collected.first();
                 if (!((s4d.reply) == 'cancel')) {
                  s4d.database.set(String((String(s4d.database.get(String(((s4dmessage.author).id)))) + '-pub')), (s4d.reply));
                  (s4dmessage.channel).send({
                              embeds: [new MessageEmbed()
                  .setTitle(String((String(s4d.database.get(String('good_emoji'))) + ' | Tout est bon !')))
                  .setColor(String(s4d.database.get(String('embed_color'))))
                  .setDescription(String('Votre choix a bien été sauvegardé !'))
                              ]
                      });
                  await delay(Number(2)*1000);
                  (s4dmessage.channel).bulkDelete((3|1));
                }

               s4d.reply = null; }).catch(async (e) => { console.error(e);  });
              })
            }
            if ((i.customId) == 's_perso' && (i.values[0]) == 'reason_sp') {
              (s4dmessage.channel).send({
                          embeds: [new MessageEmbed()
              .setTitle(String('<:1_perso_emoji_chanel:925368816706396210> | Raison du salon'))
              .setColor(String(s4d.database.get(String('embed_color'))))
              .setDescription(String('Sélectionnez la raison du salon personnalisé.'))
                          ]
                  ,components:[(new MessageActionRow()
                  .addComponents(
                  new MessageSelectMenu()
                  .setCustomId('reason-1')
                  .setPlaceholder('Menu déroulant')
                  .setMaxValues(1)
                  .setMinValues(1)
                  .setDisabled(false)


                  .addOptions(  {
                value:'buy',
                label:'Achat Boutique',
                emoji:'<:business_perso_emoji_boutique:925802618859687977>',
                description:'Le salon personnalisé à été acheté via la boutique.',
                default:false,},
                {
                value:'giveaway',
                label:'Giveaway Gagné',
                emoji:'<:1_perso_emoji_reward:925423898152022037>',
                description:'Un salon personnalisé a été gagné dans un giveaway.',
                default:false,},
                {
                value:'other',
                label:'Autre',
                emoji:'<:business_perso_emoji_news:925359761300533258>',
                description:'Le salon personnalisé a été obtenu pour une raison non définie.',
                default:false,},
              ))
              )]}).then(m=>{
                                let collector = m.createMessageComponentCollector({filter: i=>i.user.id === (s4dmessage.member).id ,time:60000});
                    collector.on('collect',async i=>{
                          if ((i.customId) == 'reason-1' && (i.values[0]) == 'other') {
                    s4d.database.set(String((String(s4d.database.get(String(((s4dmessage.author).id)))) + '-reason')), '*Autre/Non précisé*');
                    (s4dmessage.channel).send({
                                embeds: [new MessageEmbed()
                    .setTitle(String((String(s4d.database.get(String('good_emoji'))) + ' | Tout est bon !')))
                    .setColor(String(s4d.database.get(String('embed_color'))))
                    .setDescription(String('Votre choix a bien été sauvegardé !'))
                                ]
                        });
                    await delay(Number(2)*1000);
                    (s4dmessage.channel).bulkDelete((1|1));
                    await i.update({ content: String('**Menu Expiré**'),components:[(new MessageActionRow()
                        .addComponents(
                        new MessageSelectMenu()
                        .setCustomId('reason-1')
                        .setPlaceholder('Menu déroulant')
                        .setMaxValues(1)
                        .setMinValues(1)
                        .setDisabled(false)


                        .addOptions(  {
                      value:'buy',
                      label:'Achat Boutique',
                      emoji:'<:business_perso_emoji_boutique:925802618859687977>',
                      description:'Le salon personnalisé à été acheté via la boutique.',
                      default:false,},
                      {
                      value:'giveaway',
                      label:'Giveaway Gagné',
                      emoji:'<:1_perso_emoji_reward:925423898152022037>',
                      description:'Un salon personnalisé a été gagné dans un giveaway.',
                      default:false,},
                      {
                      value:'other',
                      label:'Autre',
                      emoji:'<:business_perso_emoji_news:925359761300533258>',
                      description:'Le salon personnalisé a été obtenu pour une raison non définie.',
                      default:false,},
                    ))
                    )]}).then(m=>{

                                });
                    await i.deleteReply()
                  }
                  if ((i.customId) == 'reason-1' && (i.values[0]) == 'giveaway') {
                    s4d.database.set(String((String(s4d.database.get(String(((s4dmessage.author).id)))) + '-reason')), '*Récompense Giveaway*');
                    (s4dmessage.channel).send({
                                embeds: [new MessageEmbed()
                    .setTitle(String((String(s4d.database.get(String('good_emoji'))) + ' | Tout est bon !')))
                    .setColor(String(s4d.database.get(String('embed_color'))))
                    .setDescription(String('Votre choix a bien été sauvegardé !'))
                                ]
                        });
                    await delay(Number(2)*1000);
                    (s4dmessage.channel).bulkDelete((1|1));
                    await i.update({ content: String('**Menu Expiré**'),components:[(new MessageActionRow()
                        .addComponents(
                        new MessageSelectMenu()
                        .setCustomId('reason-1')
                        .setPlaceholder('Menu déroulant')
                        .setMaxValues(1)
                        .setMinValues(1)
                        .setDisabled(false)


                        .addOptions(  {
                      value:'buy',
                      label:'Achat Boutique',
                      emoji:'<:business_perso_emoji_boutique:925802618859687977>',
                      description:'Le salon personnalisé à été acheté via la boutique.',
                      default:false,},
                      {
                      value:'giveaway',
                      label:'Giveaway Gagné',
                      emoji:'<:1_perso_emoji_reward:925423898152022037>',
                      description:'Un salon personnalisé a été gagné dans un giveaway.',
                      default:false,},
                      {
                      value:'other',
                      label:'Autre',
                      emoji:'<:business_perso_emoji_news:925359761300533258>',
                      description:'Le salon personnalisé a été obtenu pour une raison non définie.',
                      default:false,},
                    ))
                    )]}).then(m=>{

                                });
                    await i.deleteReply()
                  }
                  if ((i.customId) == 'reason-1' && (i.values[0]) == 'buy') {
                    s4d.database.set(String((String(s4d.database.get(String(((s4dmessage.author).id)))) + '-reason')), '*Achat Boutique*');
                    (s4dmessage.channel).send({
                                embeds: [new MessageEmbed()
                    .setTitle(String((String(s4d.database.get(String('good_emoji'))) + ' | Tout est bon !')))
                    .setColor(String(s4d.database.get(String('embed_color'))))
                    .setDescription(String('Votre choix a bien été sauvegardé !'))
                                ]
                        });
                    await delay(Number(2)*1000);
                    (s4dmessage.channel).bulkDelete((1|1));
                    await i.update({ content: String('**Menu Expiré**'),components:[(new MessageActionRow()
                        .addComponents(
                        new MessageSelectMenu()
                        .setCustomId('reason-1')
                        .setPlaceholder('Menu déroulant')
                        .setMaxValues(1)
                        .setMinValues(1)
                        .setDisabled(false)


                        .addOptions(  {
                      value:'buy',
                      label:'Achat Boutique',
                      emoji:'<:business_perso_emoji_boutique:925802618859687977>',
                      description:'Le salon personnalisé à été acheté via la boutique.',
                      default:false,},
                      {
                      value:'giveaway',
                      label:'Giveaway Gagné',
                      emoji:'<:1_perso_emoji_reward:925423898152022037>',
                      description:'Un salon personnalisé a été gagné dans un giveaway.',
                      default:false,},
                      {
                      value:'other',
                      label:'Autre',
                      emoji:'<:business_perso_emoji_news:925359761300533258>',
                      description:'Le salon personnalisé a été obtenu pour une raison non définie.',
                      default:false,},
                    ))
                    )]}).then(m=>{

                                });
                    await i.deleteReply()
                  }

                    })

                          });
            }
            if ((i.customId) == 's_perso' && (i.values[0]) == 'ping_sp') {
              (s4dmessage.channel).send({
                          embeds: [new MessageEmbed()
              .setTitle(String('<:business_perso_emoji_ping:925431173247807528> | Mention du salon'))
              .setColor(String(s4d.database.get(String('embed_color'))))
              .setDescription(String('Veuillez sélectionner via le menu la mention achetée .'))
                          ]
                  ,components:[(new MessageActionRow()
                  .addComponents(
                  new MessageSelectMenu()
                  .setCustomId('ping-1')
                  .setPlaceholder('Menu déroulant')
                  .setMaxValues(1)
                  .setMinValues(1)
                  .setDisabled(false)


                  .addOptions(  {
                value:'everyone',
                label:'@everyone',
                emoji:'<:bot_community:986667100343001109>',
                default:false,},
                {
                value:'here',
                label:'@here',
                emoji:'<:bot_link:986666351139651654>',
                default:false,},
                {
                value:'notif_autres',
                label:'@🔔┊Notifications Autre',
                emoji:'<:bot_premium:986666391803428894>',
                default:false,},
                {
                value:'aucune_sp',
                label:'Aucune',
                emoji:'<:bot_muted:986666385763627078>',
                default:false,},
              ))
              )]}).then(m=>{
                                let collector = m.createMessageComponentCollector({filter: i=>i.user.id === (s4dmessage.member).id ,time:60000});
                    collector.on('collect',async i=>{
                          if ((i.customId) == 'ping-1' && (i.values[0]) == 'aucune_sp') {
                    s4d.database.set(String((String(s4d.database.get(String(((s4dmessage.author).id)))) + '-ping')), '`Aucune`');
                    (s4dmessage.channel).send({
                                embeds: [new MessageEmbed()
                    .setTitle(String((String(s4d.database.get(String('good_emoji'))) + ' | Tout est bon !')))
                    .setColor(String(s4d.database.get(String('embed_color'))))
                    .setDescription(String('Votre choix a bien été sauvegardé !'))
                                ]
                        });
                    await delay(Number(2)*1000);
                    (s4dmessage.channel).bulkDelete((1|1));
                    await i.update({ content: String('**Menu Expiré**'),components:[(new MessageActionRow()
                        .addComponents(
                        new MessageSelectMenu()
                        .setCustomId('ping-1')
                        .setPlaceholder('Menu déroulant')
                        .setMaxValues(1)
                        .setMinValues(1)
                        .setDisabled(false)


                        .addOptions(  {
                      value:'everyone',
                      label:'@everyone',
                      emoji:'<:business_perso_emoji_role:926081749556019232>',
                      default:false,},
                      {
                      value:'here',
                      label:'@here',
                      emoji:'<:business_perso_emoji_role:926081749556019232>',
                      default:false,},
                      {
                      value:'notif_autres',
                      label:'@🔔┊Notifications Autre',
                      emoji:'<:business_perso_emoji_role:926081749556019232>',
                      default:false,},
                    ))
                    )]}).then(m=>{

                                });
                    await i.deleteReply()
                  }
                  if ((i.customId) == 'ping-1' && (i.values[0]) == 'notif_autres') {
                    s4d.database.set(String((String(s4d.database.get(String(((s4dmessage.author).id)))) + '-ping')), '<@&790517373374824489>');
                    (s4dmessage.channel).send({
                                embeds: [new MessageEmbed()
                    .setTitle(String((String(s4d.database.get(String('good_emoji'))) + ' | Tout est bon !')))
                    .setColor(String(s4d.database.get(String('embed_color'))))
                    .setDescription(String('Votre choix a bien été sauvegardé !'))
                                ]
                        });
                    await delay(Number(2)*1000);
                    (s4dmessage.channel).bulkDelete((1|1));
                    await i.update({ content: String('**Menu Expiré**'),components:[(new MessageActionRow()
                        .addComponents(
                        new MessageSelectMenu()
                        .setCustomId('ping-1')
                        .setPlaceholder('Menu déroulant')
                        .setMaxValues(1)
                        .setMinValues(1)
                        .setDisabled(false)


                        .addOptions(  {
                      value:'everyone',
                      label:'@everyone',
                      emoji:'<:business_perso_emoji_role:926081749556019232>',
                      default:false,},
                      {
                      value:'here',
                      label:'@here',
                      emoji:'<:business_perso_emoji_role:926081749556019232>',
                      default:false,},
                      {
                      value:'notif_autres',
                      label:'@🔔┊Notifications Autre',
                      emoji:'<:business_perso_emoji_role:926081749556019232>',
                      default:false,},
                    ))
                    )]}).then(m=>{

                                });
                    await i.deleteReply()
                  }
                  if ((i.customId) == 'ping-1' && (i.values[0]) == 'here') {
                    s4d.database.set(String((String(s4d.database.get(String(((s4dmessage.author).id)))) + '-ping')), '@here');
                    (s4dmessage.channel).send({
                                embeds: [new MessageEmbed()
                    .setTitle(String((String(s4d.database.get(String('good_emoji'))) + ' | Tout est bon !')))
                    .setColor(String(s4d.database.get(String('embed_color'))))
                    .setDescription(String('Votre choix a bien été sauvegardé !'))
                                ]
                        });
                    await delay(Number(2)*1000);
                    (s4dmessage.channel).bulkDelete((1|1));
                    await i.update({ content: String('**Menu Expiré**'),components:[(new MessageActionRow()
                        .addComponents(
                        new MessageSelectMenu()
                        .setCustomId('ping-1')
                        .setPlaceholder('Menu déroulant')
                        .setMaxValues(1)
                        .setMinValues(1)
                        .setDisabled(false)


                        .addOptions(  {
                      value:'everyone',
                      label:'@everyone',
                      emoji:'<:business_perso_emoji_role:926081749556019232>',
                      default:false,},
                      {
                      value:'here',
                      label:'@here',
                      emoji:'<:business_perso_emoji_role:926081749556019232>',
                      default:false,},
                      {
                      value:'notif_autres',
                      label:'@🔔┊Notifications Autre',
                      emoji:'<:business_perso_emoji_role:926081749556019232>',
                      default:false,},
                    ))
                    )]}).then(m=>{

                                });
                    await i.deleteReply()
                  }
                  if ((i.customId) == 'ping-1' && (i.values[0]) == 'everyone') {
                    s4d.database.set(String((String(s4d.database.get(String(((s4dmessage.author).id)))) + '-ping')), '@everyone');
                    (s4dmessage.channel).send({
                                embeds: [new MessageEmbed()
                    .setTitle(String((String(s4d.database.get(String('good_emoji'))) + ' | Tout est bon !')))
                    .setColor(String(s4d.database.get(String('embed_color'))))
                    .setDescription(String('Votre choix a bien été sauvegardé !'))
                                ]
                        });
                    await delay(Number(2)*1000);
                    (s4dmessage.channel).bulkDelete((1|1));
                    await i.update({ content: String('**Menu Expiré**'),components:[(new MessageActionRow()
                        .addComponents(
                        new MessageSelectMenu()
                        .setCustomId('ping-1')
                        .setPlaceholder('Menu déroulant')
                        .setMaxValues(1)
                        .setMinValues(1)
                        .setDisabled(false)


                        .addOptions(  {
                      value:'everyone',
                      label:'@everyone',
                      emoji:'<:business_perso_emoji_role:926081749556019232>',
                      default:false,},
                      {
                      value:'here',
                      label:'@here',
                      emoji:'<:business_perso_emoji_role:926081749556019232>',
                      default:false,},
                      {
                      value:'notif_autres',
                      label:'@🔔┊Notifications Autre',
                      emoji:'<:business_perso_emoji_role:926081749556019232>',
                      default:false,},
                    ))
                    )]}).then(m=>{

                                });
                    await i.deleteReply()
                  }

                    })

                          });
            }
            if ((i.customId) == 's_perso' && (i.values[0]) == 'time_sp') {
              (s4dmessage.channel).send({
                          embeds: [new MessageEmbed()
              .setTitle(String('🕰️ | Temps du salon'))
              .setColor(String(s4d.database.get(String('embed_color'))))
              .setDescription(String('Veuillez sélectionner via le menu le temps du salon personnalisé.'))
                          ]
                  ,components:[(new MessageActionRow()
                  .addComponents(
                  new MessageSelectMenu()
                  .setCustomId('time-1')
                  .setPlaceholder('Menu déroulant')
                  .setMaxValues(1)
                  .setMinValues(1)
                  .setDisabled(false)


                  .addOptions(  {
                value:'3d',
                label:'3 Jours',
                emoji:'⏱️',
                default:false,},
                {
                value:'7d',
                label:'7 Jours',
                emoji:'⏱️',
                default:false,},
                {
                value:'14d',
                label:'14 Jours',
                emoji:'⏱️',
                default:false,},
                {
                value:'1m',
                label:'1 Mois',
                emoji:'⏱️',
                default:false,},
              ))
              )]}).then(m=>{
                                let collector = m.createMessageComponentCollector({filter: i=>i.user.id === (s4dmessage.member).id ,time:60000});
                    collector.on('collect',async i=>{
                          if ((i.customId) == 'time-1' && (i.values[0]) == '1m') {
                    s4d.database.set(String((String(s4d.database.get(String(((s4dmessage.author).id)))) + '-time')), '1 Mois');
                    s4d.database.set(String((String(s4d.database.get(String(((s4dmessage.author).id)))) + '-date_create')), ((new Date().getDate())));
                    (s4dmessage.channel).send({
                                embeds: [new MessageEmbed()
                    .setTitle(String((String(s4d.database.get(String('good_emoji'))) + ' | Tout est bon !')))
                    .setColor(String(s4d.database.get(String('embed_color'))))
                    .setDescription(String('Votre choix a bien été sauvegardé !'))
                                ]
                        });
                    await delay(Number(2)*1000);
                    (s4dmessage.channel).bulkDelete((1|1));
                    await i.update({ content: String('**Menu Expiré**'),components:[(new MessageActionRow()
                        .addComponents(
                        new MessageSelectMenu()
                        .setCustomId('time-1')
                        .setPlaceholder('Menu déroulant')
                        .setMaxValues(1)
                        .setMinValues(1)
                        .setDisabled(false)


                        .addOptions(  {
                      value:'3d',
                      label:'3 Jours',
                      emoji:'⏱️',
                      default:false,},
                      {
                      value:'7d',
                      label:'7 Jours',
                      emoji:'⏱️',
                      default:false,},
                      {
                      value:'14d',
                      label:'14 Jours',
                      emoji:'⏱️',
                      default:false,},
                      {
                      value:'1m',
                      label:'1 Mois',
                      emoji:'⏱️',
                      default:false,},
                    ))
                    )]}).then(m=>{

                                });
                    await i.deleteReply()
                  }
                  if ((i.customId) == 'time-1' && (i.values[0]) == '14d') {
                    s4d.database.set(String((String(s4d.database.get(String(((s4dmessage.author).id)))) + '-time')), '14 Jours');
                    s4d.database.set(String((String(s4d.database.get(String(((s4dmessage.author).id)))) + '-date_create')), ((new Date().getDate())));
                    (s4dmessage.channel).send({
                                embeds: [new MessageEmbed()
                    .setTitle(String((String(s4d.database.get(String('good_emoji'))) + ' | Tout est bon !')))
                    .setColor(String(s4d.database.get(String('embed_color'))))
                    .setDescription(String('Votre choix a bien été sauvegardé !'))
                                ]
                        });
                    await delay(Number(2)*1000);
                    (s4dmessage.channel).bulkDelete((1|1));
                    await i.update({ content: String('**Menu Expiré**'),components:[(new MessageActionRow()
                        .addComponents(
                        new MessageSelectMenu()
                        .setCustomId('time-1')
                        .setPlaceholder('Menu déroulant')
                        .setMaxValues(1)
                        .setMinValues(1)
                        .setDisabled(false)


                        .addOptions(  {
                      value:'3d',
                      label:'3 Jours',
                      emoji:'⏱️',
                      default:false,},
                      {
                      value:'7d',
                      label:'7 Jours',
                      emoji:'⏱️',
                      default:false,},
                      {
                      value:'14d',
                      label:'14 Jours',
                      emoji:'⏱️',
                      default:false,},
                      {
                      value:'1m',
                      label:'1 Mois',
                      emoji:'⏱️',
                      default:false,},
                    ))
                    )]}).then(m=>{

                                });
                    await i.deleteReply()
                  }
                  if ((i.customId) == 'time-1' && (i.values[0]) == '7d') {
                    s4d.database.set(String((String(s4d.database.get(String(((s4dmessage.author).id)))) + '-time')), '7 Jours');
                    s4d.database.set(String((String(s4d.database.get(String(((s4dmessage.author).id)))) + '-date_create')), ((new Date().getDate())));
                    (s4dmessage.channel).send({
                                embeds: [new MessageEmbed()
                    .setTitle(String((String(s4d.database.get(String('good_emoji'))) + ' | Tout est bon !')))
                    .setColor(String(s4d.database.get(String('embed_color'))))
                    .setDescription(String('Votre choix a bien été sauvegardé !'))
                                ]
                        });
                    await delay(Number(2)*1000);
                    (s4dmessage.channel).bulkDelete((1|1));
                    await i.update({ content: String('**Menu Expiré**'),components:[(new MessageActionRow()
                        .addComponents(
                        new MessageSelectMenu()
                        .setCustomId('time-1')
                        .setPlaceholder('Menu déroulant')
                        .setMaxValues(1)
                        .setMinValues(1)
                        .setDisabled(false)


                        .addOptions(  {
                      value:'3d',
                      label:'3 Jours',
                      emoji:'⏱️',
                      default:false,},
                      {
                      value:'7d',
                      label:'7 Jours',
                      emoji:'⏱️',
                      default:false,},
                      {
                      value:'14d',
                      label:'14 Jours',
                      emoji:'⏱️',
                      default:false,},
                      {
                      value:'1m',
                      label:'1 Mois',
                      emoji:'⏱️',
                      default:false,},
                    ))
                    )]}).then(m=>{

                                });
                    await i.deleteReply()
                  }
                  if ((i.customId) == 'time-1' && (i.values[0]) == '3d') {
                    s4d.database.set(String((String(s4d.database.get(String(((s4dmessage.author).id)))) + '-time')), '3 Jours');
                    s4d.database.set(String((String(s4d.database.get(String(((s4dmessage.author).id)))) + '-date_create')), ((new Date().getDate())));
                    (s4dmessage.channel).send({
                                embeds: [new MessageEmbed()
                    .setTitle(String((String(s4d.database.get(String('good_emoji'))) + ' | Tout est bon !')))
                    .setColor(String(s4d.database.get(String('embed_color'))))
                    .setDescription(String('Votre choix a bien été sauvegardé !'))
                                ]
                        });
                    await delay(Number(2)*1000);
                    (s4dmessage.channel).bulkDelete((1|1));
                    await i.update({ content: String('**Menu Expiré**'),components:[(new MessageActionRow()
                        .addComponents(
                        new MessageSelectMenu()
                        .setCustomId('time-1')
                        .setPlaceholder('Menu déroulant')
                        .setMaxValues(1)
                        .setMinValues(1)
                        .setDisabled(false)


                        .addOptions(  {
                      value:'3d',
                      label:'3 Jours',
                      emoji:'⏱️',
                      default:false,},
                      {
                      value:'7d',
                      label:'7 Jours',
                      emoji:'⏱️',
                      default:false,},
                      {
                      value:'14d',
                      label:'14 Jours',
                      emoji:'⏱️',
                      default:false,},
                      {
                      value:'1m',
                      label:'1 Mois',
                      emoji:'⏱️',
                      default:false,},
                    ))
                    )]}).then(m=>{

                                });
                    await i.deleteReply()
                  }

                    })

                          });
            }
            if ((i.customId) == 's_perso' && (i.values[0]) == 'ok') {
              if (s4d.database.has(String((String(s4d.database.get(String(((s4dmessage.author).id)))) + '-time'))) && s4d.database.has(String((String(s4d.database.get(String(((s4dmessage.author).id)))) + '-ping'))) && s4d.database.has(String((String(s4d.database.get(String(((s4dmessage.author).id)))) + '-reason'))) && s4d.database.has(String((String(s4d.database.get(String(((s4dmessage.author).id)))) + '-pub'))) && s4d.database.has(String((String(s4d.database.get(String(((s4dmessage.author).id)))) + '-name')))) {
                (s4dmessage.channel).send({
                            embeds: [new MessageEmbed()
                .setTitle(String((String(s4d.database.get(String('settings_emoji'))) + ' | Prévisualisation du salon personnalisé')))
                .setColor(String(s4d.database.get(String('embed_color'))))
                .setDescription(String((['> <:item_warn:884051646433329152>__** | Informations extérieurs:**__','\n','\n','<:1_perso_emoji_chanel:925368816706396210> **| Nom du salon:** *',s4d.database.get(String((String(s4d.database.get(String(((s4dmessage.author).id)))) + '-name'))),'*','\n','\n','> <:business_perso_emoji_news:925359761300533258> **| Message:**','\n','\n','*Pour avoir le même salon rendez-vous dans <#901894881608359967> !*','\n','\n','> <:item_user:916648174532300830> **| Responsable du salon:** <@',s4d.database.get(String(((s4dmessage.author).id))),'>','\n','> <:business_perso_emoji_diary:925874517740486656> **|Temps du salon:** `',s4d.database.get(String((String(s4d.database.get(String(((s4dmessage.author).id)))) + '-time'))),'`','\n','> <:business_perso_emoji_role:926081749556019232> **| Mention:** ',s4d.database.get(String((String(s4d.database.get(String(((s4dmessage.author).id)))) + '-ping'))),'\n','> <:1_perso_emoji_chanel:925368816706396210> **| Raison:** ',s4d.database.get(String((String(s4d.database.get(String(((s4dmessage.author).id)))) + '-reason'))),'\n','\n','> <:business_perso_emoji_news:925359761300533258> **| Publicité:**','\n','\n','\n',s4d.database.get(String((String(s4d.database.get(String(((s4dmessage.author).id)))) + '-pub')))].join(''))))
                            ]
                    ,components:[(new MessageActionRow()
                .addComponents(  new MessageButton()
                  .setCustomId('go-1')
                  .setLabel('Lancer')
                  .setEmoji('')
                  .setStyle(('SUCCESS')),
                  new MessageButton()
                  .setCustomId('stop-1')
                  .setLabel('Annuler')
                  .setEmoji('')
                  .setStyle(('DANGER')),
                ))]}).then(m=>{
                                  let collector = m.createMessageComponentCollector({filter: i=>i.user.id === (s4dmessage.member).id ,time:60000});
                      collector.on('collect',async i=>{
                            if ((i.customId) == 'go-1') {
                      (s4dmessage.guild).channels.create(s4d.database.get(String((String(s4d.database.get(String(((s4dmessage.author).id)))) + '-name'))), { type: 'text', parent: '829440340779860029' });
                      await delay(Number(1)*1000);
                      s4d.client.channels.cache.get(s4d.database.get(String('id_chanel'))).send({content:String((['','','','','','','','','','','','*Pour avoir le même salon rendez-vous dans <#901894881608359967> !*','\n','\n','> <:item_user:916648174532300830> **| Responsable du salon:** <@',s4d.database.get(String(((s4dmessage.author).id))),'>','\n','> <:business_perso_emoji_diary:925874517740486656> **|Temps du salon:** `',s4d.database.get(String((String(s4d.database.get(String(((s4dmessage.author).id)))) + '-time'))),'`','\n','> <:business_perso_emoji_role:926081749556019232> **| Mention:** ',s4d.database.get(String((String(s4d.database.get(String(((s4dmessage.author).id)))) + '-ping'))),'\n','> <:1_perso_emoji_chanel:925368816706396210> **| Raison:** ',s4d.database.get(String((String(s4d.database.get(String(((s4dmessage.author).id)))) + '-reason'))),'\n','\n','> <:business_perso_emoji_news:925359761300533258> **| Publicité:**','\n','\n','\n',s4d.database.get(String((String(s4d.database.get(String(((s4dmessage.author).id)))) + '-pub')))].join('')))});
                      (s4dmessage.channel).send({
                                  embeds: [new MessageEmbed()
                      .setTitle(String((String(s4d.database.get(String('good_emoji'))) + ' | Configuration Terminée !')))
                      .setColor(String(s4d.database.get(String('embed_color'))))
                      .setDescription(String('Le salon personnalisé a bien été crée !'))
                                  ]
                          });
                    }
                    if ((i.customId) == 'stop-1') {
                      (s4dmessage.channel).send({
                                  embeds: [new MessageEmbed()
                      .setTitle(String((String(s4d.database.get(String('accessdenied_emoji'))) + ' | Configuration annulée !')))
                      .setColor(String(s4d.database.get(String('embed_color'))))
                      .setDescription(String('La configuration a bien été stoppée !'))
                                  ]
                          });
                      await delay(Number(2)*1000);
                      (s4dmessage.channel).bulkDelete((1|1));
                    }

                      })

                            });
              } else {
                (s4dmessage.channel).send({
                            embeds: [new MessageEmbed()
                .setTitle(String((String(s4d.database.get(String('error_emoji'))) + ' | Une erreur est survenue !')))
                .setColor(String(s4d.database.get(String('embed_color'))))
                .setDescription(String('Vous devez configurer tous les boutons.'))
                            ]
                    });
                await delay(Number(2)*1000);
                (s4dmessage.channel).bulkDelete((1|1));
              }
            }

              })

                    });
      }
    }
  }

});

// Commandes d'aide
s4d.client.on('messageCreate', async (s4dmessage) => {
  if ((s4dmessage.content) == String(s4d.database.get(String('prefix'))) + 'help') {
    (s4dmessage.channel).send({
                embeds: [new MessageEmbed()
    .setTitle(String((String(s4d.database.get(String('bot_emoji'))) + '** | Business Bot V3 - Menu d\'aide**')))
    .setColor(String(s4d.database.get(String('embed_color'))))
    .setDescription(String((['**<a:bot_house:986675888911446066> | Menu Principal**','\n','\n','- Bot `officiel` de **',(s4dmessage.guild).name,'**, je possède de nombreuses commandes que vous pouvez consulter en interagissant avec le menu.','\n','\n','- Mon développeur est **',(((s4dmessage.guild).members.cache.get('397406757422628869') || await (s4dmessage.guild).members.fetch('397406757422628869')).user).tag,' ( <@397406757422628869> )**, si tu veux avoir une version similaire de moi-même, contact le par MP.','\n','\n','<a:bot_loupe:986674310913617920> **| Légende:**','\n','\n','- *<a:bot_good:986673556777734206> | commande `Disponible`*','\n','- *<a:bot_notgood:986673549773266954> | commande `Indisponible`*','','',''].join(''))))
                ]
        ,components:[(new MessageActionRow()
        .addComponents(
        new MessageSelectMenu()
        .setCustomId('help-menu')
        .setPlaceholder('Interagir pour consulter les comandes')
        .setMaxValues(1)
        .setMinValues(1)
        .setDisabled(false)


        .addOptions(  {
      value:'menu_house',
      label:'Menu Principal',
      emoji:'<a:bot_house:986675888911446066>',
      description:'Retourner au menu principal',
      default:false,},
      {
      value:'menu_utils',
      label:'Utilitaire',
      emoji:'<:bot_tools:986669486461575270>',
      description:'Commandes utilitaires',
      default:false,},
      {
      value:'menu_music',
      label:'Juke-Box',
      emoji:'<:bot_radio:986669484695756830>',
      description:'Commandes de musique',
      default:false,},
      {
      value:'menu_moderator',
      label:'Modération',
      emoji:'<:bot_moderator:986669488466456636>',
      description:'Commandes de modération',
      default:false,},
      {
      value:'menu_admin',
      label:'Propriétaires',
      emoji:'<:bot_owner:986666412795920435>',
      description:'Commandes accessible seulement par les propriétaires',
      default:false,},
    ))
    )]}).then(m=>{
                      let collector = m.createMessageComponentCollector({filter: i=>i.user.id === (s4dmessage.member).id ,time:60000});
          collector.on('collect',async i=>{
                if ((i.customId) == 'help-menu' && (i.values[0]) == 'menu_admin') {
          await i.update({
                      embeds: [new MessageEmbed()
          .setTitle(String((String(s4d.database.get(String('bot_emoji'))) + '** | Business Bot V3 - Menu d\'aide**')))
          .setColor(String(s4d.database.get(String('embed_color'))))
          .setDescription(String((['> <a:bot_good:986673556777734206> `!demote` = *Retirer tous les rôles d\'un haut gradé.*','\n','> <a:bot_good:986673556777734206> `!ghostping` = *Configurer le système de ghostping.*','\n','> <a:bot_good:986673556777734206> `!manage-pub` = *Gérer le système d\'embed derrière les publicités.*','\n','> <a:bot_good:986673556777734206> `!color_embed` = *Modifier la couleur de tous les embeds du bot.*','\n','> <a:bot_good:986673556777734206> `!message_mp` = *Configurer le message à envoyer aux nouveaux.*','\n','> <a:bot_good:986673556777734206> `!partenariat_add` = *Ajouter les accès à la commande de partenariat à un nouveau équipier.*','\n','> <a:bot_good:986673556777734206> `!partenariat_remove` = *Retirer les accès à la commande de partenariat à un équipier.*','\n','> <a:bot_good:986673556777734206> `!shutdown` = *Eteindre le bot.*','\n','> <a:bot_good:986673556777734206> `!money_add` = *Ajouter des coins à un équipier.*','\n','> <a:bot_good:986673556777734206> `!money_remove` = *Enlever des coins à un équipier.*','\n','> <a:bot_good:986673556777734206> `!say` = *Faire parler le bot.*','\n','> <a:bot_good:986673556777734206> `!embed` = *Envoyer un embed de qualité !*'].join(''))))
                      ]
              ,components:[(new MessageActionRow()
              .addComponents(
              new MessageSelectMenu()
              .setCustomId('help-menu')
              .setPlaceholder('Interagir pour consulter les comandes')
              .setMaxValues(1)
              .setMinValues(1)
              .setDisabled(false)


              .addOptions(  {
            value:'menu_house',
            label:'Menu Principal',
            emoji:'<a:bot_house:986675888911446066>',
            description:'Retourner au menu principal',
            default:false,},
            {
            value:'menu_utils',
            label:'Utilitaire',
            emoji:'<:bot_tools:986669486461575270>',
            description:'Commandes utilitaires',
            default:false,},
            {
            value:'menu_music',
            label:'Juke-Box',
            emoji:'<:bot_radio:986669484695756830>',
            description:'Commandes de musique',
            default:false,},
            {
            value:'menu_moderator',
            label:'Modération',
            emoji:'<:bot_moderator:986669488466456636>',
            description:'Commandes de modération',
            default:false,},
            {
            value:'menu_admin',
            label:'Propriétaires',
            emoji:'<:bot_owner:986666412795920435>',
            description:'Commandes accessible seulement par les propriétaires',
            default:false,},
          ))
          )]}).then(m=>{

                      });
        }
        if ((i.customId) == 'help-menu' && (i.values[0]) == 'menu_utils') {
          await i.update({
                      embeds: [new MessageEmbed()
          .setTitle(String((String(s4d.database.get(String('bot_emoji'))) + '** | Business Bot V3 - Menu d\'aide**')))
          .setColor(String(s4d.database.get(String('embed_color'))))
          .setDescription(String((['> <a:bot_good:986673556777734206> `!member_count` = *Afficher le nombre de membres présents sur le serveur.*','\n','> <a:bot_good:986673556777734206> `!bot_count` = *Afficher le nombre de bots présents sur le serveur.*','\n','> <a:bot_good:986673556777734206> `!chanel_count` = *Afficher le nombre de salons sur le serveur.*','\n','> <a:bot_good:986673556777734206> `!pub_count` = *Afficher le nombre de publicités accueillies par Business Pub depuis la V1 du bot.*','\n','> <a:bot_good:986673556777734206> `!level` = *Afficher le niveau atteint par un utilisateur.*','\n','> <a:bot_good:986673556777734206> `!xp` = *Afficher le nombre d\'XP atteints par un utilisateur.*','\n','> <a:bot_good:986673556777734206> `!ping` = *Afficher le ping du bot.*','','','','','','','','',''].join(''))))
                      ]
              ,components:[(new MessageActionRow()
              .addComponents(
              new MessageSelectMenu()
              .setCustomId('help-menu')
              .setPlaceholder('Interagir pour consulter les comandes')
              .setMaxValues(1)
              .setMinValues(1)
              .setDisabled(false)


              .addOptions(  {
            value:'menu_house',
            label:'Menu Principal',
            emoji:'<a:bot_house:986675888911446066>',
            description:'Retourner au menu principal',
            default:false,},
            {
            value:'menu_utils',
            label:'Utilitaire',
            emoji:'<:bot_tools:986669486461575270>',
            description:'Commandes utilitaires',
            default:false,},
            {
            value:'menu_music',
            label:'Juke-Box',
            emoji:'<:bot_radio:986669484695756830>',
            description:'Commandes de musique',
            default:false,},
            {
            value:'menu_moderator',
            label:'Modération',
            emoji:'<:bot_moderator:986669488466456636>',
            description:'Commandes de modération',
            default:false,},
            {
            value:'menu_admin',
            label:'Propriétaires',
            emoji:'<:bot_owner:986666412795920435>',
            description:'Commandes accessible seulement par les propriétaires',
            default:false,},
          ))
          )]}).then(m=>{

                      });
        }
        if ((i.customId) == 'help-menu' && (i.values[0]) == 'menu_music') {
          await i.update({
                      embeds: [new MessageEmbed()
          .setTitle(String((String(s4d.database.get(String('bot_emoji'))) + '** | Business Bot V3 - Menu d\'aide**')))
          .setColor(String(s4d.database.get(String('embed_color'))))
          .setDescription(String((['> <a:bot_good:986673556777734206> `!play` = *Allumer la musique.*','\n','> <a:bot_good:986673556777734206> `!stop` = *Stopper la musique en cours.*','\n','> <a:bot_good:986673556777734206> `!pause` = *Mettre la musique en cours sur pause.*','\n','> <a:bot_good:986673556777734206> `!resume` = *Reprendre une musique mise sur pause.*','\n','> <a:bot_good:986673556777734206> `!volume` = *Gérer le volume.*','\n','> <a:bot_good:986673556777734206> `!skip` = *Passer à la musique suivante.*','\n','> <a:bot_good:986673556777734206> `!back` = *Réécouter la musique précédente.*','','','','','','','','',''].join(''))))
                      ]
              ,components:[(new MessageActionRow()
              .addComponents(
              new MessageSelectMenu()
              .setCustomId('help-menu')
              .setPlaceholder('Interagir pour consulter les comandes')
              .setMaxValues(1)
              .setMinValues(1)
              .setDisabled(false)


              .addOptions(  {
            value:'menu_house',
            label:'Menu Principal',
            emoji:'<a:bot_house:986675888911446066>',
            description:'Retourner au menu principal',
            default:false,},
            {
            value:'menu_utils',
            label:'Utilitaire',
            emoji:'<:bot_tools:986669486461575270>',
            description:'Commandes utilitaires',
            default:false,},
            {
            value:'menu_music',
            label:'Juke-Box',
            emoji:'<:bot_radio:986669484695756830>',
            description:'Commandes de musique',
            default:false,},
            {
            value:'menu_moderator',
            label:'Modération',
            emoji:'<:bot_moderator:986669488466456636>',
            description:'Commandes de modération',
            default:false,},
            {
            value:'menu_admin',
            label:'Propriétaires',
            emoji:'<:bot_owner:986666412795920435>',
            description:'Commandes accessible seulement par les propriétaires',
            default:false,},
          ))
          )]}).then(m=>{

                      });
        }
        if ((i.customId) == 'help-menu' && (i.values[0]) == 'menu_house') {
          await i.update({
                      embeds: [new MessageEmbed()
          .setTitle(String((String(s4d.database.get(String('bot_emoji'))) + '** | Business Bot V3 - Menu d\'aide**')))
          .setColor(String(s4d.database.get(String('embed_color'))))
          .setDescription(String((['**<a:bot_house:986675888911446066> | Menu Principal**','\n','\n','- Bot `officiel` de **',(s4dmessage.guild).name,'**, je possède de nombreuses commandes que vous pouvez consulter en interagissant avec le menu.','\n','\n','- Mon développeur est **',(((s4dmessage.guild).members.cache.get('397406757422628869') || await (s4dmessage.guild).members.fetch('397406757422628869')).user).tag,' ( <@397406757422628869> )**, si tu veux avoir une version similaire de moi-même, contact le par MP.','\n','\n','<a:bot_loupe:986674310913617920> **| Légende:**','\n','\n','- *<a:bot_good:986673556777734206> | commande `Disponible`*','\n','- *<a:bot_notgood:986673549773266954> | commande `Indisponible`*','','',''].join(''))))
                      ]
              ,components:[(new MessageActionRow()
              .addComponents(
              new MessageSelectMenu()
              .setCustomId('help-menu')
              .setPlaceholder('Interagir pour consulter les comandes')
              .setMaxValues(1)
              .setMinValues(1)
              .setDisabled(false)


              .addOptions(  {
            value:'menu_house',
            label:'Menu Principal',
            emoji:'<a:bot_house:986675888911446066>',
            description:'Retourner au menu principal',
            default:false,},
            {
            value:'menu_utils',
            label:'Utilitaire',
            emoji:'<:bot_tools:986669486461575270>',
            description:'Commandes utilitaires',
            default:false,},
            {
            value:'menu_music',
            label:'Juke-Box',
            emoji:'<:bot_radio:986669484695756830>',
            description:'Commandes de musique',
            default:false,},
            {
            value:'menu_moderator',
            label:'Modération',
            emoji:'<:bot_moderator:986669488466456636>',
            description:'Commandes de modération',
            default:false,},
            {
            value:'menu_admin',
            label:'Propriétaires',
            emoji:'<:bot_owner:986666412795920435>',
            description:'Commandes accessible seulement par les propriétaires',
            default:false,},
          ))
          )]}).then(m=>{

                      });
        }
        if ((i.customId) == 'help-menu' && (i.values[0]) == 'menu_moderator') {
          await i.update({
                      embeds: [new MessageEmbed()
          .setTitle(String((String(s4d.database.get(String('bot_emoji'))) + '** | Business Bot V3 - Menu d\'aide**')))
          .setColor(String(s4d.database.get(String('embed_color'))))
          .setDescription(String((['> <a:bot_good:986673556777734206> `!ban` = *Bannir un utilisateur du serveur.*','\n','> <a:bot_good:986673556777734206> `!unban` = *Debannir un utilisateur du serveur.*','\n','> <a:bot_good:986673556777734206> `!kick` = *Expulser un utilisateur du serveur.*','\n','> <a:bot_good:986673556777734206> `!clear` = *Effacer un certain nombre de message.*','\n','> <a:bot_good:986673556777734206> `!clear` = *Effacer un certain nombre de message.*','\n','> <a:bot_good:986673556777734206> `!partenariat` = *Configurer un partenariat.*','\n','> <a:bot_good:986673556777734206> `!partenariat_count/!part_count` = *Afficher le nombre de partenariats faits.*','\n','> <a:bot_good:986673556777734206> `!pub` = *Afficher la publicité du serveur.*','\n','> <a:bot_good:986673556777734206> `!part_infos` = *Afficher les conditions partenariats.*','\n','> <a:bot_good:986673556777734206> `!rc` = *Afficher les conditions et les informations à propos des recrutements staff.*','\n','> <a:bot_good:986673556777734206> `!recrue` = *Donner les rôles nécessaires aux nouveaux équipiers.*','\n','> <a:bot_good:986673556777734206> `!demote_staff` = *Retirer tous les rôles d\'un staff.*','\n','> <a:bot_good:986673556777734206> `!money` = *Afficher le nombre de coins détenu(s) par un équipier.*','','','',''].join(''))))
                      ]
              ,components:[(new MessageActionRow()
              .addComponents(
              new MessageSelectMenu()
              .setCustomId('help-menu')
              .setPlaceholder('Interagir pour consulter les comandes')
              .setMaxValues(1)
              .setMinValues(1)
              .setDisabled(false)


              .addOptions(  {
            value:'menu_house',
            label:'Menu Principal',
            emoji:'<a:bot_house:986675888911446066>',
            description:'Retourner au menu principal',
            default:false,},
            {
            value:'menu_utils',
            label:'Utilitaire',
            emoji:'<:bot_tools:986669486461575270>',
            description:'Commandes utilitaires',
            default:false,},
            {
            value:'menu_music',
            label:'Juke-Box',
            emoji:'<:bot_radio:986669484695756830>',
            description:'Commandes de musique',
            default:false,},
            {
            value:'menu_moderator',
            label:'Modération',
            emoji:'<:bot_moderator:986669488466456636>',
            description:'Commandes de modération',
            default:false,},
            {
            value:'menu_admin',
            label:'Propriétaires',
            emoji:'<:bot_owner:986666412795920435>',
            description:'Commandes accessible seulement par les propriétaires',
            default:false,},
          ))
          )]}).then(m=>{

                      });
        }

          })

                });
  }

});

s4d.client.on('messageCreate', async (s4dmessage) => {
  if ((s4dmessage.content) == String(s4d.database.get(String('prefix'))) + 'partenariat') {
    if ((s4dmessage.member)._roles.includes(((s4dmessage.guild).roles.cache.get(s4d.database.get(String((String((s4dmessage.guild).id) + '-access_partenariat'))))).id)) {
      if (s4d.database.get(String((String((s4dmessage.author).id) + '-cooldown_part'))) <= (Math.floor(new Date().getTime()/1000)) || !s4d.database.has(String((String((s4dmessage.author).id) + '-cooldown_part')))) {
        (s4dmessage.channel).send({
                    embeds: [new MessageEmbed()
        .setTitle(String((String(s4d.database.get(String('partner_emoji'))) + '__**| Système de Partenariat**__')))
        .setColor(String(s4d.database.get(String('embed_color'))))
        .setDescription(String((['<:bot_files:986666375131058178> **| Description** = *Configurer la description du partenariat.*','\n','<:bot_community:986667100343001109> **| Représentant** = *Configurer le démarcheur du partenariat.*','\n','<:bot_muted:986666385763627078> **| Mention** = *Sélectionner la mention du partenariat.*',''].join(''))))
                    ]
            ,components:[(new MessageActionRow()
            .addComponents(
            new MessageSelectMenu()
            .setCustomId('partenariat_menu')
            .setPlaceholder('Avec le menu, configurez le futur partenariat !')
            .setMaxValues(1)
            .setMinValues(1)
            .setDisabled(false)


            .addOptions(  {
          value:'desc_partenariat',
          label:'Description',
          emoji:'<:bot_files:986666375131058178>',
          default:false,},
          {
          value:'resp_partenariat',
          label:'Représentant',
          emoji:'<:bot_community:986667100343001109>',
          default:false,},
          {
          value:'ping_partenariat',
          label:'Mention',
          emoji:'<:bot_muted:986666385763627078>',
          default:false,},
          {
          value:'good_partenariat',
          label:'Valider',
          emoji:'<a:bot_good:986673556777734206>',
          default:false,},
        ))
        )]}).then(m=>{
                          let collector = m.createMessageComponentCollector({filter: i=>i.user.id === (s4dmessage.member).id ,time:60000});
              collector.on('collect',async i=>{
                    if ((i.customId) == 'partenariat_menu' && (i.values[0]) == 'good_partenariat') {
              (s4dmessage.channel).send({
                          embeds: [new MessageEmbed()
              .setTitle(String((String(s4d.database.get(String('save_emoji'))) + '**| Prévisualisation de l\'annonce**')))
              .setColor(String(s4d.database.get(String('embed_color'))))
              .setDescription(String((['<:bot_files:986666375131058178> **| Salon** = <#',s4d.database.get(String((String((s4dmessage.guild).id) + '-settchanel_partenariats'))),'>','\n','\n','<:bot_edit:986666388494114866> __**| Message:**__','\n','> <:bot_community:986667100343001109> **De:** <@',s4d.database.get(String(([(s4dmessage.guild).id,'-',(s4dmessage.author).id,'resp_partenariat'].join('')))),'>','\n','> <:bot_shield:986666382735339550> **Par:** <@',(s4dmessage.author).id,'>','\n','>  <:bot_muted:986666385763627078> **Mention:** ',s4d.database.get(String(([(s4dmessage.guild).id,'-',(s4dmessage.author).id,'ping_partenariat'].join('')))),'\n','\n',s4d.database.get(String(([(s4dmessage.guild).id,'-',(s4dmessage.author).id,'desc_partenariat'].join(''))))].join(''))))
                          ]
                  ,components:[(new MessageActionRow()
              .addComponents(  new MessageButton()
                .setCustomId('verygood_partenariat')
                .setLabel('Confirmer')
                .setEmoji('<a:bot_good:986673556777734206>')
                .setStyle(('SUCCESS')),
                new MessageButton()
                .setCustomId('noverygood_partenariat')
                .setLabel('Annuler')
                .setEmoji('<a:bot_notgood:986673549773266954>')
                .setStyle(('DANGER')),
              ))]}).then(m=>{
                                let collector = m.createMessageComponentCollector({filter: i=>i.user.id === (s4dmessage.member).id ,time:60000});
                    collector.on('collect',async i=>{
                          if ((i.customId) == 'verygood_partenariat') {
                    s4d.client.channels.cache.get(s4d.database.get(String((String((s4dmessage.guild).id) + '-settchanel_partenariats')))).send({content:String((['','','','','','\n','> <:bot_community:986667100343001109> **De:** <@',s4d.database.get(String(([(s4dmessage.guild).id,'-',(s4dmessage.author).id,'resp_partenariat'].join('')))),'>','\n','> <:bot_shield:986666382735339550> **Par:** <@',(s4dmessage.author).id,'>','\n','>  <:bot_muted:986666385763627078> **Mention:** ',s4d.database.get(String(([(s4dmessage.guild).id,'-',(s4dmessage.author).id,'ping_partenariat'].join('')))),'\n','\n',s4d.database.get(String(([(s4dmessage.guild).id,'-',(s4dmessage.author).id,'desc_partenariat'].join(''))))].join('')))});
                    (((s4dmessage.guild).members.cache.get(s4d.database.get(String(([(s4dmessage.guild).id,'-',(s4dmessage.author).id,'resp_partenariat'].join(''))))) || await (s4dmessage.guild).members.fetch(s4d.database.get(String(([(s4dmessage.guild).id,'-',(s4dmessage.author).id,'resp_partenariat'].join(''))))))).roles.add(((s4dmessage.guild).roles.cache.get(s4d.database.get(String('rankadd_part')))));
                    (((s4dmessage.guild).members.cache.get(s4d.database.get(String(([(s4dmessage.guild).id,'-',(s4dmessage.author).id,'resp_partenariat'].join(''))))) || await (s4dmessage.guild).members.fetch(s4d.database.get(String(([(s4dmessage.guild).id,'-',(s4dmessage.author).id,'resp_partenariat'].join(''))))))).send({
                                embeds: [new MessageEmbed()
                    .setTitle(String((String(s4d.database.get(String('verify_emoji'))) + '__** | Certification**__')))
                    .setColor(String(s4d.database.get(String('embed_color'))))
                    .setDescription(String(('*Bonjour, je suis là pour vous avertir que le partenariat que vous avez négocié avec `Business Pub` a bien été posté sur le serveur, par conséquent je vous ai ajouté le rôle `💛┊ VIP`, bonne continuation et encore merci d\'avoir fait affaire avec nous !*' + '')))
                                ]
                        });
                    s4dmessage.reply({
                                embeds: [new MessageEmbed()
                    .setTitle(String((String(s4d.database.get(String('verify_emoji'))) + '__** | Partenariat terminé !**__')))
                    .setColor(String(s4d.database.get(String('embed_color'))))
                    .setDescription(String('Le message du partenariat a bien été envoyé dans le salon'))
                                ]
                        , allowedMentions: {
                            repliedUser: true
                        }});
                    s4d.client.channels.cache.get(s4d.database.get(String('logs_bot'))).send({
                                embeds: [new MessageEmbed()
                    .setTitle(String((String(s4d.database.get(String('save_emoji'))) + '__** | Nouveau Partenariat**__')))
                    .setColor(String(s4d.database.get(String('embed_color'))))
                    .setDescription(String((['','','','','','\n','> <:bot_community:986667100343001109> **De:** <@',s4d.database.get(String(([(s4dmessage.guild).id,'-',(s4dmessage.author).id,'resp_partenariat'].join('')))),'>','\n','> <:bot_shield:986666382735339550> **Par:** <@',(s4dmessage.author).id,'>','\n','>  <:bot_muted:986666385763627078> **Mention: **',s4d.database.get(String(([(s4dmessage.guild).id,'-',(s4dmessage.author).id,'ping_partenariat'].join('')))),'\n','\n',s4d.database.get(String(([(s4dmessage.guild).id,'-',(s4dmessage.author).id,'desc_partenariat'].join(''))))].join(''))))
                                ]
                        });
                    s4d.database.set(String((String((s4dmessage.author).id) + '-cooldown_part')), ((Math.floor(new Date().getTime()/1000)) + 300));
                    s4d.database.add(String((String((s4dmessage.author).id) + '-lb_part')), parseInt(1));
                  }
                  if ((i.customId) == 'noverygood_partenariat') {
                    s4dmessage.reply({
                                embeds: [new MessageEmbed()
                    .setTitle(String((String(s4d.database.get(String('noaccess_emoji'))) + '**| Partenariat annulé !**')))
                    .setColor(String(s4d.database.get(String('embed_color'))))
                    .setDescription(String('Le partenariat a bien été annulé !'))
                                ]
                        , allowedMentions: {
                            repliedUser: true
                        }}).then(async (s4dfrost_real_reply) =>{
                       await delay(Number(3)*1000);
                      s4dfrost_real_reply.delete();
                      s4dmessage.delete();

                    });
                  }
                  await i.update({ content: String('**Menu Expiré**'),components:[(new MessageActionRow()
                  .addComponents(  new MessageButton()
                    .setCustomId('verygood_partenariat')
                    .setLabel('Confirmer')
                    .setEmoji('<:item_good:968261893531791370>')
                    .setStyle(('SUCCESS')),
                    new MessageButton()
                    .setCustomId('noverygood_partenariat')
                    .setLabel('Annuler')
                    .setEmoji(' <:item_accessdenied:968261893745696778>')
                    .setStyle(('DANGER')),
                  ))]}).then(m=>{

                              });
                  await i.deleteReply()

                    })

                          });
              await i.update({ content: String('**Menu Expiré**'),components:[(new MessageActionRow()
                  .addComponents(
                  new MessageSelectMenu()
                  .setCustomId('partenariat_menu')
                  .setPlaceholder('Avec le menu, configurez le futur partenariat !')
                  .setMaxValues(1)
                  .setMinValues(1)
                  .setDisabled(false)


                  .addOptions(  {
                value:'desc_partenariat',
                label:'Description',
                emoji:'<:item_message:968287427909279794>',
                default:false,},
                {
                value:'resp_partenariat',
                label:'Représentant',
                emoji:'<:item_teamsupport:968263156390588436>',
                default:false,},
                {
                value:'ping_partenariat',
                label:'Mention',
                emoji:'<:item_call:968480846950576128>',
                default:false,},
                {
                value:'good_partenariat',
                label:'Valider',
                emoji:'<:item_good:968261893531791370>',
                default:false,},
              ))
              )]}).then(m=>{

                          });
              await i.deleteReply()
            }
            if ((i.customId) == 'partenariat_menu' && (i.values[0]) == 'ping_partenariat') {
              (s4dmessage.channel).send({
                          embeds: [new MessageEmbed()
              .setTitle(String((String(s4d.database.get(String('ping_emoji'))) + '**| Mention**')))
              .setColor(String(s4d.database.get(String('embed_color'))))
              .setDescription(String('Configurez la mention du partenariat à l\'aide des différents boutons !'))
                          ]
                  ,components:[(new MessageActionRow()
              .addComponents(  new MessageButton()
                .setCustomId('notifpart-ping_partenariat')
                .setLabel('Notification Partenariat')
                .setEmoji('<:bot_community:986667100343001109>')
                .setStyle(('SUCCESS')),
                new MessageButton()
                .setCustomId('zero-ping_partenariat')
                .setLabel('Aucune mention')
                .setEmoji('<:bot_muted:986666385763627078>')
                .setStyle(('SECONDARY')),
              ))]}).then(m=>{
                                let collector = m.createMessageComponentCollector({filter: i=>i.user.id === (s4dmessage.member).id ,time:60000});
                    collector.on('collect',async i=>{
                          if ((i.customId) == 'zero-ping_partenariat') {
                    s4d.database.set(String(([(s4dmessage.guild).id,'-',(s4dmessage.author).id,'ping_partenariat'].join(''))), '`Aucune`');
                    s4dmessage.reply({
                                embeds: [new MessageEmbed()
                    .setTitle(String((String(s4d.database.get(String('save_emoji'))) + '**| Donnés sauvegardées**')))
                    .setColor(String(s4d.database.get(String('embed_color'))))
                    .setDescription(String('Les informations envoyées ont bien été sauvegardées !'))
                                ]
                        , allowedMentions: {
                            repliedUser: true
                        }}).then(async (s4dfrost_real_reply) =>{
                       await delay(Number(2)*1000);
                      s4dfrost_real_reply.delete();

                    });
                  }
                  if ((i.customId) == 'notifpart-ping_partenariat') {
                    if (s4d.database.has(String((String((s4dmessage.guild).id) + '-setpingnotifpart_partenariats')))) {
                      s4d.database.set(String(([(s4dmessage.guild).id,'-',(s4dmessage.author).id,'ping_partenariat'].join(''))), (['<@&',s4d.database.get(String((String((s4dmessage.guild).id) + '-setpingnotifpart_partenariats'))),'>'].join('')));
                      s4dmessage.reply({
                                  embeds: [new MessageEmbed()
                      .setTitle(String((String(s4d.database.get(String('save_emoji'))) + '**| Donnés sauvegardées**')))
                      .setColor(String(s4d.database.get(String('embed_color'))))
                      .setDescription(String('Les informations envoyées ont bien été sauvegardées !'))
                                  ]
                          , allowedMentions: {
                              repliedUser: true
                          }}).then(async (s4dfrost_real_reply) =>{
                         await delay(Number(2)*1000);
                        s4dfrost_real_reply.delete();

                      });
                    }
                  }
                  await i.update({ content: String('**Menu Expiré**'),components:[(new MessageActionRow()
                  .addComponents(  new MessageButton()
                    .setCustomId('notifpart-ping_partenariat')
                    .setLabel('Notification Partenariat')
                    .setEmoji('<:bot_community:986667100343001109>')
                    .setStyle(('SUCCESS')),
                    new MessageButton()
                    .setCustomId('zero-ping_partenariat')
                    .setLabel('Aucune mention')
                    .setEmoji('<:bot_muted:986666385763627078>')
                    .setStyle(('SECONDARY')),
                  ))]}).then(m=>{

                              });
                  await i.deleteReply()

                    })

                          });
            }
            if ((i.customId) == 'partenariat_menu' && (i.values[0]) == 'resp_partenariat') {
              (s4dmessage.channel).send(String(([s4d.database.get(String('error_emoji')),'**| Quelle est le représentant du partenariat ?**','\n','*Entrez `cancel` pour annuler !*'].join('')))).then(() => { (s4dmessage.channel).awaitMessages({filter:(m) => m.author.id === (s4dmessage.member).id,  time: (10*60*1000), max: 1 }).then(async (collected) => { s4d.reply = collected.first().content;
               s4d.message = collected.first();
                 if (!((s4d.reply) == 'cancel')) {
                  if (((s4d.reply) || '').startsWith('<@' || '')) {
                    s4d.database.set(String(([(s4dmessage.guild).id,'-',(s4dmessage.author).id,'resp_partenariat_args'].join(''))), (s4d.reply));
                    s4d.database.set(String(([(s4dmessage.guild).id,'-',(s4dmessage.author).id,'resp_partenariat'].join(''))), (s4d.database.get(String(([(s4dmessage.guild).id,'-',(s4dmessage.author).id,'resp_partenariat_args'].join('')))).slice(2, 20)));
                    s4dmessage.reply({
                                embeds: [new MessageEmbed()
                    .setTitle(String((String(s4d.database.get(String('save_emoji'))) + '**| Donnés sauvegardées**')))
                    .setColor(String(s4d.database.get(String('embed_color'))))
                    .setDescription(String('Les informations envoyées ont bien été sauvegardées !'))
                                ]
                        , allowedMentions: {
                            repliedUser: true
                        }});
                    await delay(Number(2)*1000);
                    (s4dmessage.channel).bulkDelete((2|1));
                  } else {
                    s4d.database.set(String(([(s4dmessage.guild).id,'-',(s4dmessage.author).id,'resp_partenariat'].join(''))), (s4d.reply));
                    s4dmessage.reply({
                                embeds: [new MessageEmbed()
                    .setTitle(String((String(s4d.database.get(String('save_emoji'))) + '**| Donnés sauvegardées**')))
                    .setColor(String(s4d.database.get(String('embed_color'))))
                    .setDescription(String('Les informations envoyées ont bien été sauvegardées !'))
                                ]
                        , allowedMentions: {
                            repliedUser: true
                        }});
                    await delay(Number(2)*1000);
                    (s4dmessage.channel).bulkDelete((2|1));
                  }
                } else {
                  s4dmessage.reply({
                              embeds: [new MessageEmbed()
                  .setTitle(String((String(s4d.database.get(String('delete_emoji'))) + '**| Modifications non sauvegardées**')))
                  .setColor(String(s4d.database.get(String('embed_color'))))
                  .setDescription(String('Les informations que vous m\'avez renseignez n\'ont pas été sauvegardées !'))
                              ]
                      , allowedMentions: {
                          repliedUser: true
                      }}).then(async (s4dfrost_real_reply) =>{
                     await delay(Number(5)*1000);
                    s4dmessage.delete();

                  });
                }

               s4d.reply = null; }).catch(async (e) => { console.error(e);   s4dmessage.reply({
                            embeds: [new MessageEmbed()
                .setTitle(String((String(s4d.database.get(String('outtime_emoji'))) + '**| Le temps est écoulé**')))
                .setColor(String(s4d.database.get(String('embed_color'))))
                .setDescription(String('Vous avez mis trop de temps pour répondre !'))
                            ]
                    , allowedMentions: {
                        repliedUser: true
                    }}).then(async (s4dfrost_real_reply) =>{
                   await delay(Number(5)*1000);
                  s4dmessage.delete();

                });
               });
              })
            }
            if ((i.customId) == 'partenariat_menu' && (i.values[0]) == 'desc_partenariat') {
              (s4dmessage.channel).send(String(([s4d.database.get(String('error_emoji')),'**| Quelle est la description du partenariat ?**','\n','*Entrez `cancel` pour annuler !*'].join('')))).then(() => { (s4dmessage.channel).awaitMessages({filter:(m) => m.author.id === (s4dmessage.member).id,  time: (10*60*1000), max: 1 }).then(async (collected) => { s4d.reply = collected.first().content;
               s4d.message = collected.first();
                 if (!((s4d.reply) == 'cancel')) {
                  s4d.database.set(String(([(s4dmessage.guild).id,'-',(s4dmessage.author).id,'desc_partenariat'].join(''))), (s4d.reply));
                  s4dmessage.reply({
                              embeds: [new MessageEmbed()
                  .setTitle(String((String(s4d.database.get(String('save_emoji'))) + '**| Donnés sauvegardées**')))
                  .setColor(String(s4d.database.get(String('embed_color'))))
                  .setDescription(String('Les informations envoyées ont bien été sauvegardées !'))
                              ]
                      , allowedMentions: {
                          repliedUser: true
                      }});
                  await delay(Number(2)*1000);
                  (s4dmessage.channel).bulkDelete((2|1));
                } else {
                  s4dmessage.reply({
                              embeds: [new MessageEmbed()
                  .setTitle(String((String(s4d.database.get(String('delete_emoji'))) + '**| Modifications non sauvegardées**')))
                  .setColor(String(s4d.database.get(String('embed_color'))))
                  .setDescription(String('Les informations que vous m\'avez renseignez n\'ont pas été sauvegardées !'))
                              ]
                      , allowedMentions: {
                          repliedUser: true
                      }}).then(async (s4dfrost_real_reply) =>{
                     await delay(Number(5)*1000);
                    s4dmessage.delete();

                  });
                }

               s4d.reply = null; }).catch(async (e) => { console.error(e);   s4dmessage.reply({
                            embeds: [new MessageEmbed()
                .setTitle(String((String(s4d.database.get(String('outtime_emoji'))) + '**| Le temps est écoulé**')))
                .setColor(String(s4d.database.get(String('embed_color'))))
                .setDescription(String('Vous avez mis trop de temps pour répondre !'))
                            ]
                    , allowedMentions: {
                        repliedUser: true
                    }}).then(async (s4dfrost_real_reply) =>{
                   await delay(Number(5)*1000);
                  s4dmessage.delete();

                });
               });
              })
            }

              })

                    });
      } else {
        s4dmessage.reply({
                    embeds: [new MessageEmbed()
        .setTitle(String((String(s4d.database.get(String('noaccess_emoji'))) + '**| Un problème est survenu !**')))
        .setColor(String(s4d.database.get(String('embed_color'))))
        .setDescription(String((['*Vous devez patienter `',s4d.database.get(String((String((s4dmessage.author).id) + '-cooldown_part'))) - (Math.floor(new Date().getTime()/1000)),' secondes','','','','','` avant de pourvoir réutiliser cette commande !*'].join(''))))
                    ]
            , allowedMentions: {
                repliedUser: true
            }}).then(async (s4dfrost_real_reply) =>{
           await delay(Number(5)*1000);
          s4dfrost_real_reply.delete();
          s4dmessage.delete();

        });
      }
    } else {
      s4dmessage.reply({
                  embeds: [new MessageEmbed()
      .setTitle(String((String(s4d.database.get(String('noaccess_emoji'))) + '**| Un problème est survenu !**')))
      .setColor(String(s4d.database.get(String('embed_color'))))
      .setDescription(String((['Vous devez avoir le rôle *<@&',s4d.database.get(String((String((s4dmessage.guild).id) + '-rank_access_partenariats'))),'>* pour poursuivre !','',''].join(''))))
                  ]
          , allowedMentions: {
              repliedUser: true
          }}).then(async (s4dfrost_real_reply) =>{
         await delay(Number(5)*1000);
        s4dfrost_real_reply.delete();
        s4dmessage.delete();

      });
    }
  }

});

// Embed Système
s4d.client.on('messageCreate', async (s4dmessage) => {
  if ((s4dmessage.content) == String(s4d.database.get(String('prefix'))) + 'embed') {
    if ((s4dmessage.member)._roles.includes(((s4dmessage.guild).roles.cache.get('908517630871207966')).id)) {
      (s4dmessage.channel).send({
                  embeds: [new MessageEmbed()
      .setTitle(String((['<:bot_bot:986666343942213683> __**| Système d\'embed par `Business Bot**__','','`**__'].join(''))))
      .setColor(String(s4d.database.get(String('embed_color'))))
      .setDescription(String((['Configurez votre embed à l\'aide des différents boutons.','','','','','','',''].join(''))))
                  ]
          ,components:[(new MessageActionRow()
      .addComponents(  new MessageButton()
        .setCustomId('desc_embed')
        .setLabel('Description')
        .setEmoji('<:bot_files:986666375131058178>')
        .setStyle(('SECONDARY')),
        new MessageButton()
        .setCustomId('title_embed')
        .setLabel('Titre')
        .setEmoji('<:bot_edit:986666388494114866>')
        .setStyle(('SECONDARY')),
        new MessageButton()
        .setCustomId('color_embed')
        .setLabel('Couleur')
        .setEmoji('<:bot_captcha:986666362271322112>')
        .setStyle(('PRIMARY')),
        new MessageButton()
        .setCustomId('good_embed')
        .setEmoji('<a:bot_good:986673556777734206>')
        .setStyle(('SUCCESS')),
        new MessageButton()
        .setCustomId('notgood_embed')
        .setEmoji('<a:bot_notgood:986673549773266954>')
        .setStyle(('DANGER')),
      ))]}).then(m=>{
                        let collector = m.createMessageComponentCollector({filter: i=>i.user.id === (s4dmessage.member).id ,time:60000});
            collector.on('collect',async i=>{
                  if ((i.customId) == 'notgood_embed') {
            await i.update({ content: String('**Menu Expiré**'),components:[(new MessageActionRow()
            .addComponents(  new MessageButton()
              .setCustomId('desc_embed')
              .setLabel('Description')
              .setEmoji('<:bot_files:986666375131058178>')
              .setStyle(('SECONDARY')),
              new MessageButton()
              .setCustomId('title_embed')
              .setLabel('Titre')
              .setEmoji('<:bot_edit:986666388494114866>')
              .setStyle(('SECONDARY')),
              new MessageButton()
              .setCustomId('color_embed')
              .setLabel('Couleur')
              .setEmoji('<:bot_captcha:986666362271322112>')
              .setStyle(('PRIMARY')),
              new MessageButton()
              .setCustomId('good_embed')
              .setEmoji('<a:bot_good:986673556777734206>')
              .setStyle(('SUCCESS')),
              new MessageButton()
              .setCustomId('notgood_embed')
              .setEmoji('<a:bot_notgood:986673549773266954>')
              .setStyle(('DANGER')),
            ))]}).then(m=>{

                        });
            await i.deleteReply()
          }
          if ((i.customId) == 'good_embed') {
            (s4dmessage.channel).send({
                        embeds: [new MessageEmbed()
            .setTitle(String(s4d.database.get(String((String((s4dmessage.author).id) + 'title_embed')))))
            .setColor(String(s4d.database.get(String((String((s4dmessage.author).id) + 'color-choice_embed')))))
            .setDescription(String(s4d.database.get(String((String((s4dmessage.author).id) + 'desc_embed')))))
                        ]
                });
            await i.update({ content: String('**Menu Expiré**'),components:[(new MessageActionRow()
            .addComponents(  new MessageButton()
              .setCustomId('desc_embed')
              .setLabel('Description')
              .setEmoji('<:bot_files:986666375131058178>')
              .setStyle(('SECONDARY')),
              new MessageButton()
              .setCustomId('title_embed')
              .setLabel('Titre')
              .setEmoji('<:bot_edit:986666388494114866>')
              .setStyle(('SECONDARY')),
              new MessageButton()
              .setCustomId('color_embed')
              .setLabel('Couleur')
              .setEmoji('<:bot_captcha:986666362271322112>')
              .setStyle(('PRIMARY')),
              new MessageButton()
              .setCustomId('good_embed')
              .setEmoji('<a:bot_good:986673556777734206>')
              .setStyle(('SUCCESS')),
              new MessageButton()
              .setCustomId('notgood_embed')
              .setEmoji('<a:bot_notgood:986673549773266954>')
              .setStyle(('DANGER')),
            ))]}).then(m=>{

                        });
            await i.deleteReply()
          }
          if ((i.customId) == 'color_embed') {
            (s4dmessage.channel).send({
                        embeds: [new MessageEmbed()
            .setTitle(String(('<:bot_bot:986666343942213683> __**| Système d\'embed par `Business Bot' + '')))
            .setColor(String(s4d.database.get(String('embed_color'))))
            .setDescription(String('Choisissez parmi les couleurs ci-desous, la couleur de l\'embed.'))
                        ]
                ,components:[(new MessageActionRow()
            .addComponents(  new MessageButton()
              .setCustomId('grey_embed')
              .setLabel(' ')
              .setStyle(('SECONDARY')),
              new MessageButton()
              .setCustomId('green_embed')
              .setLabel(' ')
              .setStyle(('SUCCESS')),
              new MessageButton()
              .setCustomId('blue_embed')
              .setLabel(' ')
              .setStyle(('PRIMARY')),
              new MessageButton()
              .setCustomId('red_embed')
              .setLabel(' ')
              .setStyle(('DANGER')),
            ))]}).then(m=>{
                              let collector = m.createMessageComponentCollector({filter: i=>i.user.id === (s4dmessage.member).id ,time:60000});
                  collector.on('collect',async i=>{
                        if ((i.customId) == 'grey_embed') {
                  s4d.database.set(String((String((s4dmessage.author).id) + 'color-choice_embed')), '#52575f');
                }
                if ((i.customId) == 'green_embed') {
                  s4d.database.set(String((String((s4dmessage.author).id) + 'color-choice_embed')), '#2d7d46');
                }
                if ((i.customId) == 'blue_embed') {
                  s4d.database.set(String((String((s4dmessage.author).id) + 'color-choice_embed')), '#5865f2');
                }
                if ((i.customId) == 'red_embed') {
                  s4d.database.set(String((String((s4dmessage.author).id) + 'color-choice_embed')), '#d83c3e');
                }
                await i.update({ content: String('**Menu Expiré**'),components:[(new MessageActionRow()
                .addComponents(  new MessageButton()
                  .setCustomId('grey_embed')
                  .setLabel(' ')
                  .setStyle(('SECONDARY')),
                  new MessageButton()
                  .setCustomId('green_embed')
                  .setLabel(' ')
                  .setStyle(('SUCCESS')),
                  new MessageButton()
                  .setCustomId('blue_embed')
                  .setLabel(' ')
                  .setStyle(('PRIMARY')),
                  new MessageButton()
                  .setCustomId('red_embed')
                  .setLabel(' ')
                  .setStyle(('DANGER')),
                ))]}).then(m=>{

                            });
                await i.deleteReply()

                  })

                        });
          }
          if ((i.customId) == 'title_embed') {
            (s4dmessage.channel).send(String((['<:bot_community:986667100343001109> | Veuillez entrer le titre de l\'embed.','\n','*Entrez `cancel` pour annuler.*'].join('')))).then(() => { (s4dmessage.channel).awaitMessages({filter:(m) => m.author.id === (s4dmessage.member).id,  time: (20*60*1000), max: 1 }).then(async (collected) => { s4d.reply = collected.first().content;
             s4d.message = collected.first();
               if (!((s4d.reply) == 'cancel')) {
                s4d.database.set(String((String((s4dmessage.author).id) + 'title_embed')), (s4d.reply));
                (s4dmessage.channel).send({
                            embeds: [new MessageEmbed()
                .setTitle(String((String(s4d.database.get(String('save_emoji'))) + ' __**| Modifications sauvegardées**__')))
                .setColor(String(s4d.database.get(String('embed_color'))))
                .setDescription(String('Toutes les modifications ont bien été enregistrées !'))
                            ]
                    });
                await delay(Number(1)*1000);
                (s4dmessage.channel).bulkDelete((2|1));
              } else {
                (s4dmessage.channel).send({
                            embeds: [new MessageEmbed()
                .setTitle(String((String(s4d.database.get(String('delete_emoji'))) + ' __**| Modifications supprimées**__')))
                .setColor(String(s4d.database.get(String('embed_color'))))
                .setDescription(String('Toutes les modifications ont bien été supprimées !'))
                            ]
                    });
                (s4dmessage.channel).bulkDelete((2|1));
              }

             s4d.reply = null; }).catch(async (e) => { console.error(e);  });
            })
          }
          if ((i.customId) == 'desc_embed') {
            (s4dmessage.channel).send(String((['<:bot_community:986667100343001109> | Veuillez entrer la description de l\'embed.','\n','*Entrez `cancel` pour annuler.*'].join('')))).then(() => { (s4dmessage.channel).awaitMessages({filter:(m) => m.author.id === (s4dmessage.member).id,  time: (20*60*1000), max: 1 }).then(async (collected) => { s4d.reply = collected.first().content;
             s4d.message = collected.first();
               if (!((s4d.reply) == 'cancel')) {
                s4d.database.set(String((String((s4dmessage.author).id) + 'desc_embed')), (s4d.reply));
                (s4dmessage.channel).send({
                            embeds: [new MessageEmbed()
                .setTitle(String((String(s4d.database.get(String('save_emoji'))) + ' __**| Modifications sauvegardées**__')))
                .setColor(String(s4d.database.get(String('embed_color'))))
                .setDescription(String('Toutes les modifications ont bien été enregistrées !'))
                            ]
                    });
                await delay(Number(1)*1000);
                (s4dmessage.channel).bulkDelete((2|1));
              } else {
                (s4dmessage.channel).send({
                            embeds: [new MessageEmbed()
                .setTitle(String((String(s4d.database.get(String('delete_emoji'))) + ' __**| Modifications supprimées**__')))
                .setColor(String(s4d.database.get(String('embed_color'))))
                .setDescription(String('Toutes les modifications ont bien été supprimées !'))
                            ]
                    });
                (s4dmessage.channel).bulkDelete((2|1));
              }

             s4d.reply = null; }).catch(async (e) => { console.error(e);  });
            })
          }

            })

                  });
    } else {
      s4dmessage.reply({
                  embeds: [new MessageEmbed()
      .setTitle(String((String(s4d.database.get(String('noaccess_emoji'))) + ' **| Une erreur est survenue !**')))
      .setColor(String(s4d.database.get(String('embed_color'))))
      .setDescription(String('Pour poursuivre, vous devez posséder le rôle *<@&790517358548484158>*.'))
                  ]
          , allowedMentions: {
              repliedUser: true
          }}).then(async (s4dfrost_real_reply) =>{
         await delay(Number(3)*1000);
        s4dfrost_real_reply.delete();
        s4dmessage.delete();

      });
    }
  }

});

// Compteurs
s4d.client.on('messageCreate', async (s4dmessage) => {
  if ((s4dmessage.content) == String(s4d.database.get(String('prefix'))) + 'member_count') {
    s4dmessage.reply({
                embeds: [new MessageEmbed()
    .setTitle(String((String(s4d.database.get(String('infos_emoji'))) + '** | Nombre de membres**')))
    .setColor(String(s4d.database.get(String('embed_color'))))
    .setDescription(String((['Le serveur possède `',(s4dmessage.guild).members.cache.filter(m => !m.user.bot).size,'` membre(s) !'].join(''))))
                ]
        , allowedMentions: {
            repliedUser: true
        }});
  }
  if ((s4dmessage.content) == String(s4d.database.get(String('prefix'))) + 'bot_count') {
    s4dmessage.reply({
                embeds: [new MessageEmbed()
    .setTitle(String((String(s4d.database.get(String('infos_emoji'))) + '** | Nombre de bots**')))
    .setColor(String(s4d.database.get(String('embed_color'))))
    .setDescription(String((['Le serveur possède `',(s4dmessage.guild).members.cache.filter(m => m.user.bot).size,'` bot(s) !'].join(''))))
                ]
        , allowedMentions: {
            repliedUser: true
        }});
  }
  if ((s4dmessage.content) == String(s4d.database.get(String('prefix'))) + 'chanel_count') {
    s4dmessage.reply({
                embeds: [new MessageEmbed()
    .setTitle(String((String(s4d.database.get(String('infos_emoji'))) + '** | Nombre de salons**')))
    .setColor(String(s4d.database.get(String('embed_color'))))
    .setDescription(String((['Le serveur possède `',(s4dmessage.guild).channels.cache.size,'` salon(s) !'].join(''))))
                ]
        , allowedMentions: {
            repliedUser: true
        }});
  }
  if ((s4dmessage.content) == String(s4d.database.get(String('prefix'))) + 'pub_count') {
    s4dmessage.reply({
                embeds: [new MessageEmbed()
    .setTitle(String((String(s4d.database.get(String('infos_emoji'))) + '** | Nombre de publicités**')))
    .setColor(String(s4d.database.get(String('embed_color'))))
    .setDescription(String((['Le serveur possède `',s4d.database.get(String('total_pub')),'` publicité(s) !'].join(''))))
                ]
        , allowedMentions: {
            repliedUser: true
        }});
  }
  if ((s4dmessage.content) == String(s4d.database.get(String('prefix'))) + 'ping') {
    s4dmessage.reply({
                embeds: [new MessageEmbed()
    .setTitle(String((String(s4d.database.get(String('infos_emoji'))) + '** | Ping**')))
    .setColor(String(s4d.database.get(String('embed_color'))))
    .setDescription(String((['Mon ping est de `',s4d.client.ws.ping,'` ms !'].join(''))))
                ]
        , allowedMentions: {
            repliedUser: true
        }});
  }

});

s4d.client.on('messageDelete', async (s4dmessage) => {
  s4d.client.channels.cache.get(s4d.database.get(String('logs_bot'))).send({
              embeds: [new MessageEmbed()
  .setTitle(String((String(s4d.database.get(String('delete_emoji'))) + '** | Message supprimé**')))
  .setColor(String(s4d.database.get(String('embed_color'))))
  .setDescription(String((['**<a:bot_loupe:986674310913617920> | Salon:** `#',(s4dmessage.channel).name,' | ',(s4dmessage.channel).id,' | ',(s4dmessage.channel).parentId,'`','\n','\n','**<:bot_edit:986666388494114866> | Contenu:** ','\n','\n',s4dmessage.content,'\n','\n','**<:bot_community:986667100343001109> | Utilisateur:** ```',(s4dmessage.member.user).id,'```'].join(''))))
              ]
      });

});

s4d.client.on('messageCreate', async (s4dmessage) => {
  if ((s4dmessage.content) == String(s4d.database.get(String('prefix'))) + 'xp') {
    s4dmessage.reply({
                embeds: [new MessageEmbed()
    .setTitle(String((String(s4d.database.get(String('level_emoji'))) + '** | XP**')))
    .setColor(String(s4d.database.get(String('embed_color'))))
    .setDescription(String((['Vous avez atteint les `',s4d.database.get(String((String((s4dmessage.author).id) + '-xp'))),'/500`XP !'].join(''))))
                ]
        , allowedMentions: {
            repliedUser: true
        }});
  }
  if (((s4dmessage.content) || '').startsWith((String(s4d.database.get(String('prefix'))) + 'xp') || '')) {
    xp_args = (s4dmessage.content).split(' ');
    xp = xp_args.splice(1, 1)[0];
    if ((level || '').startsWith('<@' || '')) {
      if (!s4d.database.has(String((String((s4dmessage.mentions.members.first().user).id) + '-xp')))) {
        s4d.database.set(String((String((s4dmessage.mentions.members.first().user).id) + '-xp')), '0');
        s4dmessage.reply({
                    embeds: [new MessageEmbed()
        .setTitle(String((String(s4d.database.get(String('level_emoji'))) + '** | XP**')))
        .setColor(String(s4d.database.get(String('embed_color'))))
        .setDescription(String(([(s4dmessage.mentions.members.first().user).username,' a atteint les `',s4d.database.get(String((String((s4dmessage.mentions.members.first().user).id) + '-xp'))),'/500`XP !'].join(''))))
                    ]
            , allowedMentions: {
                repliedUser: true
            }});
      } else {
        s4dmessage.reply({
                    embeds: [new MessageEmbed()
        .setTitle(String((String(s4d.database.get(String('level_emoji'))) + '** | XP**')))
        .setColor(String(s4d.database.get(String('embed_color'))))
        .setDescription(String(([(s4dmessage.mentions.members.first().user).username,' a atteint les `',s4d.database.get(String((String((s4dmessage.mentions.members.first().user).id) + '-xp'))),'/500`XP !'].join(''))))
                    ]
            , allowedMentions: {
                repliedUser: true
            }});
      }
    } else {
      if (!s4d.database.has(String((String(level) + '-xp')))) {
        s4d.database.set(String((String(level) + '-xp')), '0');
        s4dmessage.reply({
                    embeds: [new MessageEmbed()
        .setTitle(String((String(s4d.database.get(String('level_emoji'))) + '** | XP**')))
        .setColor(String(s4d.database.get(String('embed_color'))))
        .setDescription(String(([(((s4dmessage.guild).members.cache.get(level) || await (s4dmessage.guild).members.fetch(level)).user).username,' a atteint les `',s4d.database.get(String((String(level) + '-xp'))),'/500`XP !'].join(''))))
                    ]
            , allowedMentions: {
                repliedUser: true
            }});
      } else {
        s4dmessage.reply({
                    embeds: [new MessageEmbed()
        .setTitle(String((String(s4d.database.get(String('level_emoji'))) + '** | XP**')))
        .setColor(String(s4d.database.get(String('embed_color'))))
        .setDescription(String(([(((s4dmessage.guild).members.cache.get(level) || await (s4dmessage.guild).members.fetch(level)).user).username,' a atteint les `',s4d.database.get(String((String(level) + '-level'))),'/500`XP !'].join(''))))
                    ]
            , allowedMentions: {
                repliedUser: true
            }});
      }
    }
  }
  if ((s4dmessage.content) == String(s4d.database.get(String('prefix'))) + 'level') {
    s4dmessage.reply({
                embeds: [new MessageEmbed()
    .setTitle(String((String(s4d.database.get(String('level_emoji'))) + '** | Niveau**')))
    .setColor(String(s4d.database.get(String('embed_color'))))
    .setDescription(String((['Vous avez atteint le niveau `',s4d.database.get(String((String((s4dmessage.author).id) + '-level'))),'` !'].join(''))))
                ]
        , allowedMentions: {
            repliedUser: true
        }});
  }
  if (((s4dmessage.content) || '').startsWith((String(s4d.database.get(String('prefix'))) + 'level') || '')) {
    level_args = (s4dmessage.content).split(' ');
    level = level_args.splice(1, 1)[0];
    if ((level || '').startsWith('<@' || '')) {
      if (!s4d.database.has(String((String((s4dmessage.mentions.members.first().user).id) + '-level')))) {
        s4d.database.set(String((String((s4dmessage.mentions.members.first().user).id) + '-level')), '0');
        s4dmessage.reply({
                    embeds: [new MessageEmbed()
        .setTitle(String((String(s4d.database.get(String('level_emoji'))) + '** | Niveau**')))
        .setColor(String(s4d.database.get(String('embed_color'))))
        .setDescription(String(([(s4dmessage.mentions.members.first().user).username,' a atteint le niveau `',s4d.database.get(String((String((s4dmessage.mentions.members.first().user).id) + '-level'))),'` !'].join(''))))
                    ]
            , allowedMentions: {
                repliedUser: true
            }});
      } else {
        s4dmessage.reply({
                    embeds: [new MessageEmbed()
        .setTitle(String((String(s4d.database.get(String('level_emoji'))) + '** | Niveau**')))
        .setColor(String(s4d.database.get(String('embed_color'))))
        .setDescription(String(([(s4dmessage.mentions.members.first().user).username,' a atteint le niveau `',s4d.database.get(String((String((s4dmessage.mentions.members.first().user).id) + '-level'))),'` !'].join(''))))
                    ]
            , allowedMentions: {
                repliedUser: true
            }});
      }
    } else {
      if (!s4d.database.has(String((String(level) + '-level')))) {
        s4d.database.set(String((String(level) + '-level')), '0');
        s4dmessage.reply({
                    embeds: [new MessageEmbed()
        .setTitle(String((String(s4d.database.get(String('level_emoji'))) + '** | Niveau**')))
        .setColor(String(s4d.database.get(String('embed_color'))))
        .setDescription(String(([(((s4dmessage.guild).members.cache.get(level) || await (s4dmessage.guild).members.fetch(level)).user).username,' a atteint le niveau `',s4d.database.get(String((String(level) + '-level'))),'` !'].join(''))))
                    ]
            , allowedMentions: {
                repliedUser: true
            }});
      } else {
        s4dmessage.reply({
                    embeds: [new MessageEmbed()
        .setTitle(String((String(s4d.database.get(String('level_emoji'))) + '** | Niveau**')))
        .setColor(String(s4d.database.get(String('embed_color'))))
        .setDescription(String(([(((s4dmessage.guild).members.cache.get(level) || await (s4dmessage.guild).members.fetch(level)).user).username,' a atteint le niveau `',s4d.database.get(String((String(level) + '-level'))),'` !'].join(''))))
                    ]
            , allowedMentions: {
                repliedUser: true
            }});
      }
    }
  }

});

s4d.client.on('messageCreate', async (s4dmessage) => {
        if (s4dmessage.author.bot) {
            return;
        }
          s4d.database.add(String((String((s4dmessage.author).id) + '-xp')), parseInt(10));
  if (s4d.database.get(String((String((s4dmessage.author).id) + '-xp'))) >= '500') {
    s4d.database.add(String((String((s4dmessage.author).id) + '-level')), parseInt(1));
    s4d.database.subtract(String((String((s4dmessage.author).id) + '-xp')), parseInt(500));
    s4d.client.channels.cache.get(s4d.database.get(String('lvl_chanel'))).send({
                embeds: [new MessageEmbed()
    .setTitle(String((String(s4d.database.get(String('level_emoji'))) + '** | Félicitations**')))
    .setColor(String(s4d.database.get(String('embed_color'))))
    .setDescription(String((['Bravo à <@',(s4dmessage.author).id,'','>, il a atteint le niveau `',s4d.database.get(String((String((s4dmessage.author).id) + '-level'))),'` !'].join(''))))
                ]
        });
    s4d.client.channels.cache.get(s4d.database.get(String('lvl_chanel'))).send({content:String((['<@',(s4dmessage.author).id,'>'].join('')))});
    await delay(Number(1)*1000);
    s4d.client.channels.cache.get(s4d.database.get(String('lvl_chanel'))).bulkDelete((1|1));
  }

    });

                    return s4d
                    })();